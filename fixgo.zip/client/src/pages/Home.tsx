import HeroSection from "@/components/HeroSection";
import TrustMarqueeSection from "@/components/TrustMarqueeSection";
import AboutFixgoSection from "@/components/AboutFixgoSection";
import HowItWorksSection from "@/components/HowItWorksSection";
import ServicesSection from "@/components/ServicesSection";
import FeaturedJobsSection from "@/components/FeaturedJobsSection";
import PricingCTASection from "@/components/PricingCTASection";
import TestimonialsSection from "@/components/TestimonialsSection";
import FAQSection from "@/components/FAQSection";
import FooterSection from "@/components/FooterSection";
import BookingModal from "@/components/BookingModal";
import WhatsAppButton from "@/components/WhatsAppButton";
import MobileStickyBar from "@/components/MobileStickyBar";
import NotificationToast from "@/components/NotificationToast";
import PromotionalBanner from "@/components/PromotionalBanner";

export default function Home() {
  return (
    <div className="min-h-screen overflow-x-clip">
      <PromotionalBanner />
      <HeroSection />
      <TrustMarqueeSection />
      <AboutFixgoSection />
      <HowItWorksSection />
      <ServicesSection />
      <FeaturedJobsSection />
      <PricingCTASection />
      <TestimonialsSection />
      <FAQSection />
      <FooterSection />

      {/* Overlays */}
      <BookingModal />
      <NotificationToast />
      <WhatsAppButton />
      <MobileStickyBar />
    </div>
  );
}
