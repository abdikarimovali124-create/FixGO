import { motion } from "framer-motion";
import { Shield, ArrowLeft } from "lucide-react";
import { Link } from "wouter";

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-cream/50 border-b border-charcoal/5">
        <div className="max-w-4xl mx-auto px-6 py-4 flex items-center gap-4">
          <Link href="/" className="flex items-center gap-2 text-charcoal-muted hover:text-charcoal transition-colors">
            <ArrowLeft className="w-5 h-5" />
            <span className="text-sm font-medium">Back to Fixgo</span>
          </Link>
        </div>
      </header>

      {/* Content */}
      <main className="max-w-3xl mx-auto px-6 py-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: [0.23, 1, 0.32, 1] }}
        >
          <div className="flex items-center gap-3 mb-8">
            <div className="w-12 h-12 rounded-xl bg-olive/10 flex items-center justify-center">
              <Shield className="w-6 h-6 text-olive" />
            </div>
            <h1 className="text-3xl font-bold text-charcoal">Privacy Policy</h1>
          </div>

          <p className="text-charcoal-muted text-sm mb-10">
            Last updated: July 21, 2026
          </p>

          <div className="prose prose-charcoal max-w-none space-y-8 text-charcoal/80 leading-relaxed">
            <section>
              <h2 className="text-xl font-bold text-charcoal mb-3">1. Information We Collect</h2>
              <p>
                We collect information you provide directly when using Fixgo, including your name, phone number, 
                email address, physical address for service delivery, and payment details. We also collect 
                usage data such as app interactions, service requests, device information, and location data 
                (when you grant permission) to match you with nearby professionals.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-charcoal mb-3">2. How We Use Your Information</h2>
              <p>
                Your personal data is used to provide and improve our services, match you with verified 
                professionals, process payments, communicate service updates and notifications, respond to 
                your inquiries, and comply with legal obligations. We do not use your data for purposes 
                unrelated to our service.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-charcoal mb-3">3. Information Sharing</h2>
              <p>
                We share necessary information (your name, address, and service details) with matched 
                professionals solely to facilitate service delivery. We may also share data with trusted 
                third-party service providers for payment processing, analytics, and customer support. 
                We do not sell your personal data to any third parties.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-charcoal mb-3">4. Data Security</h2>
              <p>
                We implement industry-standard security measures including SSL/TLS encryption for data 
                in transit, AES-256 encryption for data at rest, secure cloud storage, role-based access 
                controls, and regular security audits to protect your personal information from 
                unauthorized access, alteration, or disclosure.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-charcoal mb-3">5. Data Retention</h2>
              <p>
                We retain your personal data only as long as necessary to provide our services, comply 
                with legal obligations, resolve disputes, and enforce our agreements. You may request 
                deletion of your data at any time by contacting us.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-charcoal mb-3">6. Your Rights</h2>
              <p>
                You have the right to access, correct, update, or delete your personal data at any time. 
                You may also request a copy of all data we hold about you, opt out of marketing 
                communications, and withdraw consent for data processing. To exercise these rights, 
                please contact us at privacy@fixgo.uz.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-charcoal mb-3">7. Children's Privacy</h2>
              <p>
                Fixgo is not intended for use by children under the age of 16. We do not knowingly 
                collect or maintain personal information from children. If we become aware that we have 
                collected data from a child under 16, we will take steps to delete that information 
                promptly.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-charcoal mb-3">8. Changes to This Policy</h2>
              <p>
                We may update this Privacy Policy from time to time to reflect changes in our practices 
                or legal requirements. We will notify you of any material changes by posting the updated 
                policy on this page with a revised "Last updated" date. Continued use of Fixgo after 
                changes constitutes acceptance of the updated policy.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-charcoal mb-3">9. Contact Us</h2>
              <p>
                If you have any questions or concerns about this Privacy Policy or our data practices, 
                please contact us at:
              </p>
              <div className="bg-cream/50 rounded-xl p-5 mt-3">
                <p className="font-medium text-charcoal">Fixgo LLC</p>
                <p className="text-sm">Tashkent, Uzbekistan</p>
                <p className="text-sm">Email: privacy@fixgo.uz</p>
                <p className="text-sm">Phone: +998 (71) 200-00-00</p>
              </div>
            </section>
          </div>
        </motion.div>
      </main>

      {/* Footer */}
      <footer className="bg-charcoal text-white/60 text-center py-8 text-sm">
        <p>&copy; 2026 Fixgo. {new Date().getFullYear()} barcha huquqlar himoyalangan.</p>
      </footer>
    </div>
  );
}
