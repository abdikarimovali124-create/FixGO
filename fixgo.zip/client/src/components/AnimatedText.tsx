import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";

interface AnimatedTextProps {
  text: string;
  className?: string;
  startOffset?: "start 0.8" | "start 0.9";
  endOffset?: "end 0.2" | "end 0.3";
}

export default function AnimatedText({
  text,
  className = "",
  startOffset = "start 0.8",
  endOffset = "end 0.2",
}: AnimatedTextProps) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: [startOffset, endOffset],
  });

  const opacity = useTransform(scrollYProgress, [0, 1], [0.2, 1]);

  return (
    <div ref={ref} className={className}>
      <motion.p style={{ opacity }} className="leading-relaxed">
        {text}
      </motion.p>
    </div>
  );
}
