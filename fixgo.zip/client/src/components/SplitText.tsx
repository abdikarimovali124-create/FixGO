import { useGSAP } from "@gsap/react";
import gsap from "gsap";
import { useRef, type ReactNode } from "react";

interface SplitTextProps {
  children: string;
  className?: string;
  delay?: number;
  staggerDelay?: number;
  duration?: number;
  yStart?: number;
  as?: "h1" | "h2" | "p" | "span" | "div";
}

export default function SplitText({
  children,
  className = "",
  delay = 0,
  staggerDelay = 0.04,
  duration = 0.6,
  yStart = 40,
  as: Tag = "h1",
}: SplitTextProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const chars = children.split("");

  useGSAP(
    () => {
      if (!containerRef.current) return;
      const spans = containerRef.current.querySelectorAll("span");
      gsap.fromTo(
        spans,
        { opacity: 0, y: yStart },
        {
          opacity: 1,
          y: 0,
          duration,
          ease: "power3.out",
          stagger: staggerDelay,
          delay,
        }
      );
    },
    { scope: containerRef }
  );

  const Element = Tag;
  return (
    <Element className={className}>
      <div ref={containerRef}>
        {chars.map((char, i) => (
          <span
            key={i}
            className="inline-block"
            style={{ whiteSpace: char === " " ? "pre" : undefined }}
          >
            {char === " " ? "\u00A0" : char}
          </span>
        ))}
      </div>
    </Element>
  );
}
