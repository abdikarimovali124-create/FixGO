import { motion, AnimatePresence } from "framer-motion";
import { useNotification, type Notification } from "@/contexts/NotificationContext";
import { CheckCircle, Info, AlertTriangle, XCircle, X, Bell } from "lucide-react";
import { useEffect, useState } from "react";

interface ToastItem {
  notification: Notification;
  leaving: boolean;
}

const iconMap: Record<string, React.ReactNode> = {
  success: <CheckCircle className="w-5 h-5 text-green-500" />,
  info: <Info className="w-5 h-5 text-blue-500" />,
  warning: <AlertTriangle className="w-5 h-5 text-amber-500" />,
  error: <XCircle className="w-5 h-5 text-red-500" />,
};

const bgMap: Record<string, string> = {
  success: "border-green-200 bg-white",
  info: "border-blue-200 bg-white",
  warning: "border-amber-200 bg-white",
  error: "border-red-200 bg-white",
};

export default function NotificationToast() {
  const { notifications, markAsRead, removeNotification } = useNotification();
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const [queue, setQueue] = useState<Notification[]>([]);

  // Watch for new notifications and queue them
  useEffect(() => {
    const unread = notifications.filter((n) => !n.read);
    const newOnes = unread.filter(
      (n) => !toasts.some((t) => t.notification.id === n.id)
    );
    if (newOnes.length > 0) {
      setQueue((prev) => [...prev, ...newOnes]);
    }
  }, [notifications]);

  // Process queue one at a time
  useEffect(() => {
    if (queue.length === 0) return;
    const next = queue[0];
    setToasts((prev) => [
      ...prev,
      { notification: next, leaving: false },
    ]);
    setQueue((prev) => prev.slice(1));
    markAsRead(next.id);

    const timer = setTimeout(() => {
      setToasts((prev) =>
        prev.map((t) =>
          t.notification.id === next.id ? { ...t, leaving: true } : t
        )
      );
      setTimeout(() => {
        setToasts((prev) =>
          prev.filter((t) => t.notification.id !== next.id)
        );
        removeNotification(next.id);
      }, 300);
    }, 4000);

    return () => clearTimeout(timer);
  }, [queue]);

  return (
    <div className="fixed top-20 right-4 z-[90] flex flex-col gap-3 w-[340px] max-w-[calc(100vw-2rem)] pointer-events-none">
      <AnimatePresence>
        {toasts.map((item) => (
          <motion.div
            key={item.notification.id}
            initial={{ opacity: 0, x: 100, scale: 0.95 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: 100, scale: 0.95 }}
            transition={{ duration: 0.3, ease: [0.23, 1, 0.32, 1] }}
            className={`pointer-events-auto rounded-2xl border p-4 shadow-lg shadow-charcoal/8 ${bgMap[item.notification.type]}`}
          >
            <div className="flex items-start gap-3">
              <div className="mt-0.5 flex-shrink-0">{iconMap[item.notification.type]}</div>
              <div className="flex-1 min-w-0">
                <p className="text-charcoal font-semibold text-sm">{item.notification.title}</p>
                <p className="text-charcoal-muted text-xs mt-0.5 leading-relaxed">
                  {item.notification.message}
                </p>
              </div>
              <button
                onClick={() => {
                  setToasts((prev) =>
                    prev.map((t) =>
                      t.notification.id === item.notification.id
                        ? { ...t, leaving: true }
                        : t
                    )
                  );
                  setTimeout(() => {
                    setToasts((prev) =>
                      prev.filter((t) => t.notification.id !== item.notification.id)
                    );
                    removeNotification(item.notification.id);
                  }, 300);
                }}
                className="flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center text-charcoal-muted hover:text-charcoal hover:bg-charcoal/5 transition-colors"
                aria-label="Dismiss"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
