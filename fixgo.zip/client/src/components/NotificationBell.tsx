import { motion, AnimatePresence } from "framer-motion";
import { Bell, CheckCheck, Trash2, Clock } from "lucide-react";
import { useNotification } from "@/contexts/NotificationContext";

function timeAgo(timestamp: number): string {
  const diff = Date.now() - timestamp;
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "Hozirgina";
  if (mins < 60) return `${mins} daqiqa oldin`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours} soat oldin`;
  const days = Math.floor(hours / 24);
  return `${days} kun oldin`;
}

const typeColor: Record<string, string> = {
  success: "bg-green-500",
  info: "bg-blue-500",
  warning: "bg-amber-500",
  error: "bg-red-500",
};

export default function NotificationBell() {
  const {
    notifications,
    unreadCount,
    markAsRead,
    markAllAsRead,
    removeNotification,
    clearAll,
    isPanelOpen,
    setIsPanelOpen,
  } = useNotification();

  return (
    <div className="relative">
      {/* Bell button */}
      <button
        onClick={() => setIsPanelOpen(!isPanelOpen)}
        className="relative w-10 h-10 rounded-xl bg-white/80 backdrop-blur-sm border border-charcoal/10 flex items-center justify-center text-charcoal-muted hover:text-charcoal transition-colors"
        aria-label="Notifications"
      >
        <Bell className="w-5 h-5" />
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-olive text-white text-[10px] font-bold flex items-center justify-center animate-[bounce_0.5s_ease-in-out]">
            {unreadCount > 9 ? "9+" : unreadCount}
          </span>
        )}
      </button>

      {/* Panel */}
      <AnimatePresence>
        {isPanelOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="fixed inset-0 z-[99]"
              onClick={() => setIsPanelOpen(false)}
            />

            {/* Panel */}
            <motion.div
              initial={{ opacity: 0, y: 10, scale: 0.97 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 10, scale: 0.97 }}
              transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }}
              className="absolute right-0 top-12 w-[380px] max-w-[calc(100vw-2rem)] bg-white rounded-2xl shadow-2xl shadow-charcoal/15 border border-charcoal/8 z-[100] overflow-hidden"
            >
              {/* Header */}
              <div className="flex items-center justify-between px-5 py-4 border-b border-charcoal/8">
                <div className="flex items-center gap-2">
                  <Bell className="w-4 h-4 text-charcoal" />
                  <h3 className="text-charcoal font-semibold text-sm">Bildirishnomalar</h3>
                  {unreadCount > 0 && (
                    <span className="bg-olive/10 text-olive text-[10px] font-bold px-2 py-0.5 rounded-full">
                      {unreadCount} yangi
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-1">
                  {unreadCount > 0 && (
                    <button
                      onClick={markAllAsRead}
                      className="flex items-center gap-1 text-xs text-charcoal-muted hover:text-olive transition-colors px-2 py-1 rounded-lg hover:bg-olive/5"
                      title="Hammasini o'qilgan deb belgilash"
                    >
                      <CheckCheck className="w-3.5 h-3.5" />
                      Hammasini
                    </button>
                  )}
                  {notifications.length > 0 && (
                    <button
                      onClick={clearAll}
                      className="flex items-center gap-1 text-xs text-charcoal-muted hover:text-red-500 transition-colors px-2 py-1 rounded-lg hover:bg-red-50"
                      title="Hammasini o'chirish"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>

              {/* List */}
              <div className="max-h-[420px] overflow-y-auto">
                {notifications.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12 text-charcoal-muted">
                    <Bell className="w-10 h-10 mb-3 opacity-30" />
                    <p className="text-sm font-medium">Bildirishnomalar yo'q</p>
                    <p className="text-xs mt-1">Yangi bildirishnomalar bu yerda paydo bo'ladi</p>
                  </div>
                ) : (
                  <div className="divide-y divide-charcoal/5">
                    {notifications.map((notif) => (
                      <div
                        key={notif.id}
                        className={`px-5 py-4 flex items-start gap-3 transition-colors hover:bg-cream/30 ${
                          !notif.read ? "bg-olive/[0.03]" : ""
                        }`}
                      >
                        <div className={`w-2 h-2 rounded-full mt-2 flex-shrink-0 ${typeColor[notif.type]} ${!notif.read ? "" : "opacity-30"}`} />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <p className={`text-sm font-medium ${!notif.read ? "text-charcoal" : "text-charcoal-muted"}`}>
                              {notif.title}
                            </p>
                            <button
                              onClick={() => removeNotification(notif.id)}
                              className="flex-shrink-0 w-5 h-5 rounded-full flex items-center justify-center text-charcoal-muted hover:text-red-500 hover:bg-red-50 transition-colors opacity-0 group-hover:opacity-100"
                              aria-label="Remove"
                            >
                              <span className="w-2 h-2">
                                <Trash2 className="w-3 h-3" />
                              </span>
                            </button>
                          </div>
                          <p className="text-xs text-charcoal-muted mt-1 leading-relaxed">
                            {notif.message}
                          </p>
                          <div className="flex items-center gap-1 mt-2 text-[10px] text-charcoal-muted/60">
                            <Clock className="w-2.5 h-2.5" />
                            {timeAgo(notif.timestamp)}
                          </div>
                        </div>
                        {!notif.read && (
                          <button
                            onClick={() => markAsRead(notif.id)}
                            className="flex-shrink-0 w-5 h-5 rounded-full bg-olive/10 flex items-center justify-center text-olive hover:bg-olive/20 transition-colors"
                            aria-label="Mark as read"
                          >
                            <CheckCheck className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
