import { useLanguage } from "@/contexts/LanguageContext";
import {
  Wrench, Zap, SprayCan, Sofa, Palette, Shield,
  Lock, Flame, Star, Clock, Users, HeadphonesIcon,
} from "lucide-react";

const serviceCategories = [
  { icon: Wrench, name: "Santexnika" },
  { icon: Zap, name: "Elektrik" },
  { icon: SprayCan, name: "Tozalash" },
  { icon: Flame, name: "Konditsioner" },
  { icon: Sofa, name: "Mebel yig'ish" },
  { icon: Palette, name: "Bo'yoq" },
  { icon: Shield, name: "Qulflar" },
  { icon: Lock, name: "Payvandchi" },
];

export default function TrustMarqueeSection() {
  const { t } = useLanguage();

  const trustItems = [
    { icon: Shield, label: t("trust_orders") },
    { icon: Star, label: t("trust_rating") },
    { icon: Users, label: t("trust_workers") },
    { icon: HeadphonesIcon, label: t("trust_support") },
  ];

  // Doubled arrays for seamless CSS marquee loop
  const doubledServices = [...serviceCategories, ...serviceCategories];
  const doubledTrust = [...trustItems, ...trustItems];

  return (
    <section className="bg-cream pt-20 pb-14 overflow-hidden" aria-label="Trust indicators">
      {/* Row 1: Service categories - scrolling left */}
      <div className="mb-6">
        <div className="flex animate-[scroll-left_30s_linear_infinite] gap-4 w-max">
          {doubledServices.map((s, i) => (
            <div
              key={`svc-${i}`}
              className="flex-shrink-0 w-[180px] md:w-[240px] h-[120px] md:h-[150px] bg-white rounded-3xl flex flex-col items-center justify-center gap-3 shadow-sm shadow-charcoal/5 hover:shadow-lg hover:shadow-olive/5 transition-all duration-300 group"
            >
              <div className="w-11 h-11 rounded-2xl bg-olive/10 flex items-center justify-center group-hover:bg-olive/20 transition-colors">
                <s.icon className="w-5 h-5 text-olive" />
              </div>
              <span className="text-charcoal font-semibold text-sm md:text-base">{s.name}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Row 2: Trust badges - scrolling right */}
      <div>
        <div className="flex animate-[scroll-right_35s_linear_infinite] gap-4 w-max">
          {doubledTrust.map((item, i) => (
            <div
              key={`trust-${i}`}
              className="flex-shrink-0 w-[220px] md:w-[300px] h-[90px] md:h-[110px] bg-white rounded-3xl flex items-center gap-4 px-5 md:px-6 shadow-sm shadow-charcoal/5"
            >
              <div className="w-10 h-10 rounded-xl bg-olive/10 flex items-center justify-center flex-shrink-0">
                <item.icon className="w-5 h-5 text-olive" />
              </div>
              <span className="text-charcoal font-semibold text-sm md:text-base">{item.label}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
