import { motion } from "framer-motion";
import type { ReactNode } from "react";

interface AnimatedContentProps {
  children: ReactNode;
  direction?: "vertical" | "horizontal" | "scale";
  distance?: number;
  duration?: number;
  delay?: number;
  className?: string;
}

export default function AnimatedContent({
  children,
  direction = "vertical",
  distance = 100,
  duration = 1,
  delay = 0,
  className = "",
}: AnimatedContentProps) {
  const initial = {
    opacity: 0,
    x: direction === "horizontal" ? distance : 0,
    y: direction === "vertical" ? distance : 0,
    scale: direction === "scale" ? 0.9 : 1,
  };

  const animate = {
    opacity: 1,
    x: 0,
    y: 0,
    scale: 1,
  };

  return (
    <motion.div
      initial={initial}
      animate={animate}
      transition={{
        duration,
        delay,
        ease: [0.25, 0.1, 0.25, 1],
      }}
      className={className}
    >
      {children}
    </motion.div>
  );
}
