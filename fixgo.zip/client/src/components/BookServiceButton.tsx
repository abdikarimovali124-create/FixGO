import { useBooking } from "@/contexts/BookingContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { useNotification } from "@/contexts/NotificationContext";
import { useState, type ReactNode } from "react";

interface BookServiceButtonProps {
  service?: string;
  label?: ReactNode;
  size?: "sm" | "md" | "lg";
  className?: string;
  dataEvent?: string;
}

export default function BookServiceButton({
  service,
  label,
  size = "md",
  className = "",
  dataEvent = "book_click",
}: BookServiceButtonProps) {
  const { openBooking } = useBooking();
  const { t } = useLanguage();
  const { addNotification } = useNotification();
  const [isPressed, setIsPressed] = useState(false);

  const sizeClasses = {
    sm: "px-5 py-2.5 text-xs",
    md: "px-8 py-3.5 text-sm",
    lg: "px-12 py-5 text-base",
  };

  return (
    <button
      className={`cta-gradient text-white font-semibold uppercase tracking-widest rounded-full transition-all duration-160 ease-[cubic-bezier(0.23,1,0.32,1)] shadow-lg shadow-olive/20 hover:shadow-xl hover:shadow-olive/30 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-olive/50 focus-visible:ring-offset-2 ${sizeClasses[size]} ${isPressed ? "scale-[0.97]" : ""} ${className}`}
      onClick={() => {
        console.log(`[analytics] ${dataEvent}`, { service });
        addNotification({
          type: "info",
          title: t("hero_cta"),
          message: service
            ? `${t(`svc_${service}`)} xizmati tanlandi`
            : "Xizmat buyurtma qilish",
        });
        openBooking(service);
      }}
      onMouseDown={() => setIsPressed(true)}
      onMouseUp={() => setIsPressed(false)}
      onMouseLeave={() => setIsPressed(false)}
      data-event={dataEvent}
      aria-label={typeof label === "string" ? label : t("hero_cta")}
    >
      {label || t("hero_cta")}
    </button>
  );
}
