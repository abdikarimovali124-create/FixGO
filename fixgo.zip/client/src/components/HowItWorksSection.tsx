import { useGSAP } from "@gsap/react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { useRef } from "react";
import { useLanguage } from "@/contexts/LanguageContext";
import { CheckCircle, Clock, MapPin, CalendarCheck, ArrowRight } from "lucide-react";
import FadeIn from "./FadeIn";

gsap.registerPlugin(ScrollTrigger);

const STEPS = [
  { icon: CalendarCheck, num: "01" },
  { icon: MapPin, num: "02" },
  { icon: CheckCircle, num: "03" },
  { icon: Clock, num: "04" },
];

const CARD_BG = ["bg-cream", "bg-olive/90", "bg-cream", "bg-olive/90"];
const TEXT_COLOR = ["text-charcoal", "text-white", "text-charcoal", "text-white"];
const CAPTION_COLOR = ["text-charcoal-muted", "text-white/70", "text-charcoal-muted", "text-white/70"];

const imgKeys = [
  "how-it-works-1_f5e69b0d.png",
  "how-it-works-2_21c6eac8.png",
  "how-it-works-3_76f3fd22.png",
  "hero-technician_7f7347d2.png",
];

function IsometricCard({ index, title, desc }: { index: number; title: string; desc: string }) {
  const Icon = STEPS[index].icon;

  return (
    <div className="card-wrapper flex-shrink-0 w-[260px] md:w-[320px]">
      <div
        className={`relative ${CARD_BG[index]} rounded-3xl p-5 md:p-6 shadow-2xl ${
          index % 2 === 0 ? "shadow-olive/10" : "shadow-charcoal/30"
        }`}
        style={{
          transform: `perspective(1200px) rotateX(6deg) rotateY(${-10 + index * 4}deg) rotateZ(${-2 + index * 1.5}deg)`,
          willChange: "transform",
          backfaceVisibility: "hidden",
        }}
      >
        <div className="flex items-center gap-3 mb-4">
          <span
            className={`text-xs font-extrabold uppercase tracking-widest ${
              index % 2 === 0 ? "text-olive" : "text-olive-light"
            }`}
          >
            {STEPS[index].num}
          </span>
          <div
            className={`w-8 h-8 rounded-xl flex items-center justify-center ${
              index % 2 === 0 ? "bg-olive/10" : "bg-white/15"
            }`}
          >
            <Icon className={`w-4 h-4 ${index % 2 === 0 ? "text-olive" : "text-olive-light"}`} />
          </div>
        </div>

        <div className="rounded-2xl overflow-hidden mb-4 aspect-[16/10] bg-white/10">
          <img
            src={`/manus-storage/${imgKeys[index]}`}
            alt={`Step ${index + 1}`}
            className="w-full h-full object-cover"
            loading="lazy"
          />
        </div>

        <h3 className={`text-base md:text-lg font-bold ${TEXT_COLOR[index]} mb-1`}>{title}</h3>
        <p className={`text-xs md:text-sm ${CAPTION_COLOR[index]}`}>{desc}</p>
      </div>
    </div>
  );
}

export default function HowItWorksSection() {
  const { t } = useLanguage();
  const sectionRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);

  const steps = [
    { title: t("hiw_step1"), desc: t("hiw_step1_desc") },
    { title: t("hiw_step2"), desc: t("hiw_step2_desc") },
    { title: t("hiw_step3"), desc: t("hiw_step3_desc") },
    { title: t("hiw_step4"), desc: t("hiw_step4_desc") },
  ];

  useGSAP(
    () => {
      const section = sectionRef.current;
      const track = trackRef.current;
      if (!section || !track) return;

      const scrollWidth = track.scrollWidth - track.offsetWidth;

      gsap.to(track, {
        x: -scrollWidth * 0.5,
        ease: "none",
        scrollTrigger: {
          trigger: section,
          start: "top 20%",
          end: "bottom 80%",
          scrub: 1,
        },
      });
    },
    { scope: sectionRef }
  );

  return (
    <section
      id="how-it-works"
      ref={sectionRef}
      className="bg-charcoal py-24 md:py-32 overflow-hidden relative"
    >
      <FadeIn className="text-center mb-14 px-6">
        <div className="inline-flex items-center gap-2 bg-olive/20 text-olive-light px-4 py-1.5 rounded-full text-xs font-semibold uppercase tracking-wider mb-6">
          Qanday ishlaydi
        </div>
        <h2
          className="hero-heading font-bold uppercase tracking-tight"
          style={{ fontSize: "clamp(2rem, 8vw, 5rem)" }}
        >
          {t("hiw_heading")}
        </h2>
      </FadeIn>

      {/* Desktop: Diagonal scroll track */}
      <div className="hidden md:block overflow-hidden">
        <div
          ref={trackRef}
          className="flex gap-8 px-8 lg:px-16 py-6"
          style={{ willChange: "transform" }}
        >
          {steps.map((step, i) => (
            <div key={i} className="flex items-center">
              <IsometricCard index={i} title={step.title} desc={step.desc} />
              {i < steps.length - 1 && (
                <ArrowRight className="w-6 h-6 text-olive/30 mx-4 flex-shrink-0" />
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Mobile: Vertical stacked cards */}
      <div className="md:hidden px-6 space-y-6">
        {steps.map((step, i) => {
          const Icon = STEPS[i].icon;
          return (
          <div
            key={i}
            className={`${CARD_BG[i]} rounded-2xl p-5 shadow-lg ${
              i % 2 === 0 ? "shadow-olive/10" : "shadow-charcoal/20"
            }`}
          >
            <div className="flex items-center gap-3 mb-3">
              <span
                className={`text-xs font-extrabold uppercase tracking-widest ${
                  i % 2 === 0 ? "text-olive" : "text-olive-light"
                }`}
              >
                {STEPS[i].num}
              </span>
              <div
                className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                  i % 2 === 0 ? "bg-olive/10" : "bg-white/15"
                }`}
              >
                <Icon className={`w-4 h-4 ${i % 2 === 0 ? "text-olive" : "text-olive-light"}`} />
              </div>
            </div>
            <h3 className={`text-base font-bold ${TEXT_COLOR[i]} mb-1`}>{step.title}</h3>
            <p className={`text-sm ${CAPTION_COLOR[i]}`}>{step.desc}</p>
          </div>
          );
        })}
      </div>
    </section>
  );
}
