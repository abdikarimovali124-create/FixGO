import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import FadeIn from "./FadeIn";
import { useLanguage } from "@/contexts/LanguageContext";
import { Star, ChevronLeft, ChevronRight } from "lucide-react";

const testimonials = [
  {
    name: "Dilnoza K.",
    city: "Chilonzor, Toshkent",
    rating: 5,
    text_uz: "Santexnik 20 daqiqada keldi, juda professional edi. Narxi ham juda arzon chiqdi. Rahmat Fixgo!",
    text_ru: "Сантехник приехал за 20 минут, очень профессиональный. Цена оказалась очень доступной. Спасибо Fixgo!",
    text_en: "The plumber arrived in 20 minutes, very professional. The price was very affordable. Thank you Fixgo!",
  },
  {
    name: "Akmal R.",
    city: "Yakkasaroy, Toshkent",
    rating: 5,
    text_uz: "Elektrik ustasi juda yaxshi ish qildi. Ilova juda qulay, hamma narsa shaffof.",
    text_ru: "Электрик сделал отличную работу. Приложение очень удобное, всё прозрачно.",
    text_en: "The electrician did excellent work. The app is very convenient, everything is transparent.",
  },
  {
    name: "Nodira M.",
    city: "Mirzo Ulug'bek, Toshkent",
    rating: 4,
    text_uz: "Tozalash xizmati ajoyib. Uyim juda toza bo'ldi. Keyingi safar ham Fixgo dan foydalanaman.",
    text_ru: "Уборка была отличной. Дом стал очень чистым. В следующий раз тоже буду пользоваться Fixgo.",
    text_en: "Cleaning service was amazing. My home is very clean now. I'll use Fixgo again next time.",
  },
  {
    name: "Bobur T.",
    city: "Shayxontohur, Toshkent",
    rating: 5,
    text_uz: "IKEA mebelini yig'ish uchun usta chaqirdim. 2 soatda hamma narsa tayyor bo'ldi. Super!",
    text_ru: "Вызвал мастера для сборки мебели IKEA. За 2 часа всё было готово. Супер!",
    text_en: "Called a pro to assemble IKEA furniture. Everything was done in 2 hours. Super!",
  },
  {
    name: "Zilola A.",
    city: "Sergeli, Toshkent",
    rating: 5,
    text_uz: "Konditsioner o'rnatish juda tez va sifatli amalga oshirildi. Usta juda madaniyatli edi.",
    text_ru: "Установка кондиционера была выполнена быстро и качественно. Мастер был очень вежливый.",
    text_en: "AC installation was done quickly and professionally. The technician was very courteous.",
  },
];

export default function TestimonialsSection() {
  const { language, t } = useLanguage();
  const [current, setCurrent] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  useEffect(() => {
    if (!isAutoPlaying) return;
    const interval = setInterval(() => {
      setCurrent((prev) => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [isAutoPlaying]);

  const getTestimonialText = (test: typeof testimonials[0]) => {
    if (language === "ru") return test.text_ru;
    if (language === "en") return test.text_en;
    return test.text_uz;
  };

  return (
    <section className="bg-white py-24 px-6">
      <div className="max-w-4xl mx-auto">
        <FadeIn>
          <h2
            className="font-bold uppercase tracking-tight text-center mb-16"
            style={{ fontSize: "clamp(2rem, 8vw, 4rem)", color: "#1F1E1B" }}
          >
            {t("testimonials_heading")}
          </h2>
        </FadeIn>

        <FadeIn delay={0.1}>
          <div className="relative">
            <AnimatePresence mode="wait">
              <motion.div
                key={current}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
                className="bg-cream/50 rounded-3xl p-8 md:p-12 text-center"
                onMouseEnter={() => setIsAutoPlaying(false)}
                onMouseLeave={() => setIsAutoPlaying(true)}
              >
                {/* Stars */}
                <div className="flex items-center justify-center gap-1 mb-6">
                  {Array.from({ length: testimonials[current].rating }).map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-amber-400 fill-amber-400" />
                  ))}
                </div>

                {/* Quote */}
                <p className="text-charcoal text-lg md:text-xl leading-relaxed font-light mb-8">
                  "{getTestimonialText(testimonials[current])}"
                </p>

                {/* Author */}
                <div className="flex items-center justify-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-olive/20 flex items-center justify-center text-olive font-bold text-sm">
                    {testimonials[current].name[0]}
                  </div>
                  <div className="text-left">
                    <p className="text-charcoal font-medium text-sm">{testimonials[current].name}</p>
                    <p className="text-charcoal-muted text-xs">{testimonials[current].city}</p>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>

            {/* Navigation */}
            <div className="flex items-center justify-center gap-4 mt-8">
              <button
                onClick={() => setCurrent((prev) => (prev - 1 + testimonials.length) % testimonials.length)}
                className="w-10 h-10 rounded-full border border-charcoal/15 flex items-center justify-center text-charcoal-muted hover:text-charcoal hover:border-charcoal/30 transition-colors"
                aria-label="Previous testimonial"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>

              {/* Dots */}
              <div className="flex items-center gap-2">
                {testimonials.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setCurrent(i)}
                    className={`w-2 h-2 rounded-full transition-all duration-300 ${
                      i === current ? "w-6 bg-olive" : "bg-charcoal/20 hover:bg-charcoal/30"
                    }`}
                    aria-label={`Go to testimonial ${i + 1}`}
                  />
                ))}
              </div>

              <button
                onClick={() => setCurrent((prev) => (prev + 1) % testimonials.length)}
                className="w-10 h-10 rounded-full border border-charcoal/15 flex items-center justify-center text-charcoal-muted hover:text-charcoal hover:border-charcoal/30 transition-colors"
                aria-label="Next testimonial"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </FadeIn>
      </div>
    </section>
  );
}
