import { motion, AnimatePresence } from "framer-motion";
import { useState, useEffect } from "react";
import { Sparkles, X, ArrowRight } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { useNotification } from "@/contexts/NotificationContext";

interface BannerData {
  title_uz: string;
  title_ru: string;
  title_en: string;
  message_uz: string;
  message_ru: string;
  message_en: string;
  cta: string;
  type: "promo" | "info" | "urgent";
}

const banners: BannerData[] = [
  {
    title_uz: "20% chegirma!",
    title_ru: "Скидка 20%!",
    title_en: "20% off!",
    message_uz: "Birinchi buyurtmangizda 20% chegirma. \"FIXGO20\" promokodidan foydalaning.",
    message_ru: "Скидка 20% на первый заказ. Используйте промокод FIXGO20.",
    message_en: "Get 20% off your first booking. Use promo code FIXGO20.",
    cta: "Buyurtma berish",
    type: "promo",
  },
  {
    title_uz: "Yangi shahar!",
    title_ru: "Новый город!",
    title_en: "New city!",
    message_uz: "Endi Samarqandda ham xizmat ko'rsatamiz. Batafsil ma'lumot oling.",
    message_ru: "Теперь мы работаем и в Самарканде. Узнайте подробности.",
    message_en: "We're now available in Samarkand. Learn more.",
    cta: "Batafsil",
    type: "info",
  },
  {
    title_uz: "Tezkor xizmat!",
    title_ru: "Быстрая служба!",
    title_en: "Express service!",
    message_uz: "24/7 tez xizmat endi barcha xizmat turlari uchun mavjud.",
    message_ru: "Круглосуточный экспресс-сервис теперь доступен для всех услуг.",
    message_en: "24/7 express service now available for all service types.",
    cta: "Hoziroq buyurtma qiling",
    type: "urgent",
  },
];

const bgMap: Record<string, string> = {
  promo: "bg-gradient-to-r from-olive/90 via-olive to-charcoal",
  info: "bg-gradient-to-r from-[#1a3a4a] to-[#2a5a6a]",
  urgent: "bg-gradient-to-r from-[#4a1a1a] to-[#6a2a2a]",
};

export default function PromotionalBanner() {
  const { language, t } = useLanguage();
  const { addNotification } = useNotification();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [dismissed, setDismissed] = useState(() => {
    return sessionStorage.getItem("banner_dismissed") === "true";
  });
  const [isVisible, setIsVisible] = useState(false);

  const banner = banners[currentIndex];

  // Show after 3 seconds delay
  useEffect(() => {
    const timer = setTimeout(() => {
      if (!dismissed) setIsVisible(true);
    }, 3000);
    return () => clearTimeout(timer);
  }, [dismissed]);

  // Auto-rotate banners
  useEffect(() => {
    if (dismissed) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % banners.length);
    }, 8000);
    return () => clearInterval(interval);
  }, [dismissed]);

  const handleDismiss = () => {
    setDismissed(true);
    setIsVisible(false);
    sessionStorage.setItem("banner_dismissed", "true");
    // Add to notification history
    addNotification({
      type: "info",
      title: banner[`title_${language}` as keyof typeof banner] as string,
      message: banner[`message_${language}` as keyof typeof banner] as string,
    });
  };

  const getText = (field: keyof BannerData) => {
    const key = `${field}_${language}`;
    return (banner[key as keyof BannerData] as string) || banner[`${field}_uz` as keyof BannerData] as string;
  };

  return (
    <AnimatePresence>
      {isVisible && !dismissed && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
          className={`fixed top-0 left-0 right-0 z-[80] ${bgMap[banner.type]} py-3 px-4`}
        >
          <div className="max-w-6xl mx-auto flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <Sparkles className="w-5 h-5 text-white/80 flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-white font-bold text-sm md:text-base">{getText("title_uz" as keyof BannerData)}</p>
                <p className="text-white/70 text-xs md:text-sm truncate">{getText("message_uz" as keyof BannerData)}</p>
              </div>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <button
                onClick={() => {
                  handleDismiss();
                }}
                className="hidden md:flex items-center gap-1.5 bg-white/15 hover:bg-white/25 text-white text-xs font-medium px-4 py-2 rounded-full transition-colors"
              >
                {banner.cta}
                <ArrowRight className="w-3 h-3" />
              </button>
              <button
                onClick={handleDismiss}
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors"
                aria-label="Close banner"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
