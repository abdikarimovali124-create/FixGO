interface ViewJobButtonProps {
  label: string;
  onClick?: () => void;
  className?: string;
}

export default function ViewJobButton({ label, onClick, className = "" }: ViewJobButtonProps) {
  return (
    <button
      className={`border-2 border-[#F3EFE6] rounded-full text-[#F3EFE6] px-6 py-2.5 text-sm font-medium transition-all duration-200 hover:bg-[#F3EFE6]/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cream/50 ${className}`}
      onClick={onClick}
    >
      {label}
    </button>
  );
}
