import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import FadeIn from "./FadeIn";
import { useLanguage } from "@/contexts/LanguageContext";

export default function FAQSection() {
  const { t } = useLanguage();

  const faqs = [
    { q: t("faq1_q"), a: t("faq1_a") },
    { q: t("faq2_q"), a: t("faq2_a") },
    { q: t("faq3_q"), a: t("faq3_a") },
    { q: t("faq4_q"), a: t("faq4_a") },
  ];

  return (
    <section className="bg-cream/50 py-24 px-6">
      <div className="max-w-3xl mx-auto">
        <FadeIn>
          <h2
            className="font-bold uppercase tracking-tight text-center mb-12"
            style={{ fontSize: "clamp(1.5rem, 6vw, 3rem)", color: "#1F1E1B" }}
          >
            {t("faq_heading")}
          </h2>
        </FadeIn>

        <FadeIn delay={0.1}>
          <Accordion type="single" collapsible className="space-y-3">
            {faqs.map((faq, i) => (
              <AccordionItem
                key={i}
                value={`faq-${i}`}
                className="bg-white rounded-2xl px-6 border border-charcoal/5 data-[state=open]:shadow-md data-[state=open]:shadow-charcoal/5 transition-shadow duration-300"
              >
                <AccordionTrigger className="text-charcoal font-medium text-sm md:text-base py-5 hover:no-underline">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="text-charcoal-muted text-sm md:text-base pb-5 leading-relaxed">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </FadeIn>
      </div>
    </section>
  );
}
