import { Wrench, Zap, SprayCan, Sofa } from "lucide-react";
import FadeIn from "./FadeIn";
import AnimatedText from "./AnimatedText";
import BookServiceButton from "./BookServiceButton";
import { useLanguage } from "@/contexts/LanguageContext";

const cornerIcons = [
  { icon: Wrench, position: "top-16 left-6 md:left-16", delay: 0, x: -80 },
  { icon: Zap, position: "top-20 right-8 md:right-20", delay: 0.1, x: 80 },
  { icon: SprayCan, position: "bottom-24 left-10 md:left-24", delay: 0.2, x: -80 },
  { icon: Sofa, position: "bottom-20 right-6 md:right-12", delay: 0.3, x: 80 },
];

export default function AboutFixgoSection() {
  const { t } = useLanguage();

  return (
    <section className="min-h-screen flex flex-col items-center justify-center px-6 bg-cream/50 relative overflow-hidden py-28">
      {/* Corner decorative icons */}
      {cornerIcons.map((item, i) => {
        const Icon = item.icon;
        return (
          <FadeIn
            key={i}
            delay={item.delay}
            x={item.x}
            className={`absolute ${item.position} hidden md:block`}
          >
            <div className="w-14 h-14 rounded-full bg-olive/10 flex items-center justify-center shadow-sm shadow-olive/5">
              <Icon className="w-6 h-6 text-olive" />
            </div>
          </FadeIn>
        );
      })}

      <div className="max-w-3xl text-center relative z-10">
        <FadeIn delay={0.1}>
          <div className="inline-flex items-center gap-2 bg-olive/10 text-olive px-4 py-1.5 rounded-full text-xs font-semibold uppercase tracking-wider mb-8">
            Biz haqimizda
          </div>
        </FadeIn>

        <FadeIn delay={0.15}>
          <h2
            className="hero-heading font-bold uppercase tracking-tight text-center mb-8"
            style={{ fontSize: "clamp(2.5rem, 10vw, 6rem)" }}
          >
            {t("about_heading")}
          </h2>
        </FadeIn>

        <FadeIn delay={0.25} className="mt-4">
          <AnimatedText
            text={t("about_text")}
            className="text-charcoal/80 font-light text-lg md:text-xl leading-relaxed max-w-2xl mx-auto"
          />
        </FadeIn>

        {/* Stats row */}
        <FadeIn delay={0.35} className="mt-12">
          <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
            {[
              { num: "10K+", label: "Buyurtma" },
              { num: "500+", label: "Ustalar" },
              { num: "4.9", label: "Reyting" },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <p className="text-charcoal font-extrabold text-2xl md:text-3xl">{stat.num}</p>
                <p className="text-charcoal-muted text-xs mt-1">{stat.label}</p>
              </div>
            ))}
          </div>
        </FadeIn>

        <FadeIn delay={0.45} className="mt-10">
          <BookServiceButton size="md" />
        </FadeIn>
      </div>
    </section>
  );
}
