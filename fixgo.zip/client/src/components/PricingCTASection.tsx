import FadeIn from "./FadeIn";
import AnimatedContent from "./AnimatedContent";
import BookServiceButton from "./BookServiceButton";
import { useLanguage } from "@/contexts/LanguageContext";
import { Check } from "lucide-react";

const tiers = [
  {
    name_key: "pricing_standard",
    price: "50,000",
    features: ["Xizmat narxiga kiradi", "48 soat ichida", "Chat orqali qo'llab-quvvatlash"],
    recommended: false,
  },
  {
    name_key: "pricing_fast",
    price: "80,000",
    features: ["Tezkor xizmat", "60 daqiqa ichida", "24/7 qo'llab-quvvatlash", "Kafolat 30 kun"],
    recommended: true,
  },
  {
    name_key: "pricing_premium",
    price: "150,000",
    features: ["Premium xizmat", "30 daqiqa ichida", "Shaxsiy menejer", "Kafolat 90 kun", "Bepul tekshiruv"],
    recommended: false,
  },
];

export default function PricingCTASection() {
  const { t } = useLanguage();

  return (
    <section id="pricing" className="bg-cream py-24 px-6">
      <div className="max-w-5xl mx-auto">
        <FadeIn>
          <h2
            className="font-bold uppercase tracking-tight text-center mb-4"
            style={{ fontSize: "clamp(2rem, 10vw, 5rem)", color: "#1F1E1B" }}
          >
            {t("pricing_heading")}
          </h2>
        </FadeIn>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-6 mt-12">
          {tiers.map((tier, i) => (
            <AnimatedContent
              key={tier.name_key}
              direction="vertical"
              distance={60}
              duration={0.7}
              delay={i * 0.15}
              className={`relative bg-white rounded-3xl p-8 ${
                tier.recommended ? "ring-2 ring-olive shadow-xl shadow-olive/10" : "shadow-sm shadow-charcoal/5"
              }`}
            >
              {tier.recommended && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-olive text-white text-xs font-semibold px-4 py-1 rounded-full">
                  Tavsiya
                </span>
              )}
              <h3 className="text-charcoal font-semibold text-lg mb-2">{t(tier.name_key)}</h3>
              <div className="flex items-baseline gap-1 mb-6">
                <span className="text-charcoal font-bold text-3xl">{tier.price}</span>
                <span className="text-charcoal-muted text-sm">{t("svc_price")}</span>
              </div>
              <ul className="space-y-3 mb-8">
                {tier.features.map((f, fi) => (
                  <li key={fi} className="flex items-center gap-2 text-sm text-charcoal/80">
                    <Check className="w-4 h-4 text-olive flex-shrink-0" />
                    {f}
                  </li>
                ))}
              </ul>
              <button
                className={`w-full py-3 rounded-full font-medium text-sm transition-all duration-200 ${
                  tier.recommended
                    ? "cta-gradient text-white shadow-lg shadow-olive/20"
                    : "bg-cream text-charcoal hover:bg-cream/80"
                }`}
              >
                {t("svc_order")}
              </button>
            </AnimatedContent>
          ))}
        </div>

        {/* Final CTA */}
        <FadeIn delay={0.3} className="text-center mt-20">
          <BookServiceButton size="lg" label={t("pricing_cta")} />
          <p className="mt-6 text-charcoal-muted text-sm">{t("pricing_app")}</p>
          <div className="flex items-center justify-center gap-4 mt-4">
            <div className="bg-charcoal text-white px-6 py-3 rounded-xl text-sm font-medium flex items-center gap-2">
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.05 20.28c-.98.95-2.05.88-3.08.4-1.09-.5-2.08-.48-3.24 0-1.44.62-2.2.44-3.06-.4C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.5-1.31 2.99-2.54 4.09zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z"/>
              </svg>
              App Store
            </div>
            <div className="bg-charcoal text-white px-6 py-3 rounded-xl text-sm font-medium flex items-center gap-2">
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                <path d="M3.609 1.814L13.792 12 3.61 22.186a.996.996 0 01-.61-.92V2.734a1 1 0 01.609-.92zm10.89 10.893l2.302 2.302-10.937 6.333 8.635-8.635zm3.199-3.199l2.302 2.302a1 1 0 010 1.38l-2.302 2.302L15.396 13l2.302-2.492zM5.864 2.658L16.8 8.99l-2.302 2.302L5.864 2.658z"/>
              </svg>
              Google Play
            </div>
          </div>
        </FadeIn>
      </div>
    </section>
  );
}
