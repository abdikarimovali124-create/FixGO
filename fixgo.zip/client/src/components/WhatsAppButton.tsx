import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MessageCircle, X, Phone, Send } from "lucide-react";

export default function WhatsAppButton() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-3">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }}
            className="flex flex-col gap-2"
          >
            <a
              href="https://wa.me/998901234567"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 bg-green-500 text-white px-4 py-2.5 rounded-full text-sm font-medium shadow-lg hover:bg-green-600 transition-colors"
              data-event="whatsapp_click"
            >
              <Phone className="w-4 h-4" />
              WhatsApp
            </a>
            <a
              href="https://t.me/fixgo"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 bg-[#0088cc] text-white px-4 py-2.5 rounded-full text-sm font-medium shadow-lg hover:bg-[#0077b3] transition-colors"
              data-event="telegram_click"
            >
              <Send className="w-4 h-4" />
              Telegram
            </a>
          </motion.div>
        )}
      </AnimatePresence>

      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`w-14 h-14 rounded-full shadow-xl flex items-center justify-center transition-all duration-200 ${
          isOpen
            ? "bg-charcoal text-white rotate-45"
            : "bg-green-500 text-white hover:bg-green-600"
        }`}
        aria-label={isOpen ? "Close contact" : "Contact us"}
      >
        <MessageCircle className="w-6 h-6" />
      </button>
    </div>
  );
}
