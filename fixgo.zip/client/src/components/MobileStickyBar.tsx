import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import BookServiceButton from "./BookServiceButton";
import { useLanguage } from "@/contexts/LanguageContext";

export default function MobileStickyBar() {
  const { t } = useLanguage();
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setVisible(window.scrollY > window.innerHeight * 0.8);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          transition={{ duration: 0.3, ease: [0.23, 1, 0.32, 1] }}
          className="fixed bottom-0 left-0 right-0 z-50 md:hidden bg-white/90 backdrop-blur-xl border-t border-charcoal/10 px-4 py-3"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-charcoal font-semibold text-sm">{t("hero_subtext")}</p>
            </div>
            <BookServiceButton size="sm" label={t("svc_order")} />
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
