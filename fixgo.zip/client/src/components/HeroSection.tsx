import { motion } from "framer-motion";
import FadeIn from "./FadeIn"; // Used in hero body
import SplitText from "./SplitText";
import Magnet from "./Magnet";
import BookServiceButton from "./BookServiceButton";
import NotificationBell from "./NotificationBell";
import { useLanguage } from "@/contexts/LanguageContext";
import { Wrench } from "lucide-react";

const HERO_IMAGE = "/manus-storage/hero-technician_7f7347d2.png";

function LanguageSwitcher() {
  const { language, setLanguage } = useLanguage();
  const langs: { code: "uz" | "ru" | "en"; label: string }[] = [
    { code: "uz", label: "UZ" },
    { code: "ru", label: "RU" },
    { code: "en", label: "EN" },
  ];

  return (
    <div className="flex items-center gap-1 bg-white/80 backdrop-blur-sm border border-charcoal/10 rounded-full px-1.5 py-1">
      {langs.map((l) => (
        <button
          key={l.code}
          onClick={() => setLanguage(l.code)}
          className={`px-3 py-1 rounded-full text-xs font-semibold transition-all duration-200 ${
            language === l.code
              ? "bg-charcoal text-white shadow-sm"
              : "text-charcoal-muted hover:text-charcoal"
          }`}
        >
          {l.label}
        </button>
      ))}
    </div>
  );
}

function Navbar() {
  const { t } = useLanguage();
  const links = [
    { href: "#services", label: t("nav_services") },
    { href: "#how-it-works", label: t("nav_how") },
    { href: "#pricing", label: t("nav_pricing") },
    { href: "#contact", label: t("nav_contact") },
  ];

  return (
    <motion.nav
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: [0.25, 0.1, 0.25, 1] }}
      className="absolute top-0 left-0 right-0 z-50 flex items-center justify-between px-6 py-5 md:px-10 lg:px-16"
    >
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-xl bg-olive/15 flex items-center justify-center">
            <Wrench className="w-5 h-5 text-olive" />
          </div>
          <span className="text-xl font-extrabold text-charcoal tracking-tight">FixGO</span>
        </div>
        <ul className="hidden md:flex items-center gap-8">
          {links.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                className="text-charcoal uppercase tracking-wide text-sm font-medium transition-opacity duration-200 hover:opacity-60"
              >
                {link.label}
              </a>
            </li>
          ))}
        </ul>
        <div className="flex items-center gap-2">
          <NotificationBell />
          <LanguageSwitcher />
        </div>
    </motion.nav>
  );
}

function FloatingBookingCard() {
  const { t } = useLanguage();

  return (
    <motion.div
      initial={{ opacity: 0, y: 30, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.7, delay: 0.9, ease: [0.25, 0.1, 0.25, 1] }}
      className="absolute left-0 bottom-16 md:bottom-28 lg:bottom-36 -translate-x-4 md:-translate-x-8 bg-white rounded-2xl shadow-xl shadow-charcoal/8 p-4 flex items-center gap-3 z-10 max-w-[280px]"
    >
      <div className="w-10 h-10 rounded-xl bg-olive/10 flex items-center justify-center flex-shrink-0">
        <Wrench className="w-5 h-5 text-olive" />
      </div>
      <div>
        <p className="text-sm font-semibold text-charcoal leading-tight">{t("floating_service")}</p>
        <div className="flex items-center gap-1.5 mt-1">
          <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
          <span className="text-xs text-charcoal-muted font-medium">Live buyurtma</span>
        </div>
      </div>
    </motion.div>
  );
}

export default function HeroSection() {
  const { t } = useLanguage();

  return (
    <section className="h-screen min-h-[700px] flex flex-col overflow-x-clip relative bg-white">
      <Navbar />

      <div className="flex-1 flex flex-col justify-center px-6 md:px-10 lg:px-16 pb-20 md:pb-24 relative">
        {/* Main content grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-end max-w-7xl">
          {/* Left: Heading + CTA */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 bg-olive/10 text-olive px-4 py-1.5 rounded-full text-xs font-semibold uppercase tracking-wider">
              <span className="w-1.5 h-1.5 rounded-full bg-olive animate-pulse" />
              60 daqiqada uyingizda
            </div>

            <SplitText
              className="hero-heading font-black uppercase tracking-tight leading-[0.9] text-[11vw] md:text-[8vw] lg:text-[6.5vw]"
              delay={0.2}
            >
              {t("hero_heading")}
            </SplitText>

            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 mt-8">
              <FadeIn delay={0.35}>
                <p className="text-charcoal-muted font-light text-base md:text-lg leading-relaxed max-w-md">
                  {t("hero_subtext")}
                </p>
              </FadeIn>
            </div>

            <FadeIn delay={0.5}>
              <BookServiceButton size="lg" />
            </FadeIn>
          </div>

          {/* Right: Hero Image */}
          <div className="lg:col-span-5 flex justify-end">
            <FadeIn delay={0.6}>
              <Magnet padding={150} strength={3} className="relative">
                <div className="relative">
                  <img
                    src={HERO_IMAGE}
                    alt="Professional technician arriving at your home"
                    className="w-full max-w-[400px] md:max-w-[380px] lg:max-w-[460px] object-contain rounded-t-3xl"
                    loading="eager"
                  />
                  <FloatingBookingCard />
                </div>
              </Magnet>
            </FadeIn>
          </div>
        </div>
      </div>

      {/* Bottom gradient fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-cream/20 to-transparent pointer-events-none" />
    </section>
  );
}
