import { useLanguage } from "@/contexts/LanguageContext";
import { Phone, Mail, MessageCircle, Send } from "lucide-react";
import FadeIn from "./FadeIn";
import { toast } from "sonner";

const cities = ["Toshkent", "Samarqand", "Buxoro", "Namangan", "Farg'ona", "Andijon"];

export default function FooterSection() {
  const { t } = useLanguage();

  return (
    <footer id="contact" className="bg-charcoal text-cream py-20 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <FadeIn>
            <div className="flex items-center gap-3 mb-4">
              <img
                src="/manus-storage/logo-fixgo_88840ba1.png"
                alt="Fixgo"
                className="w-10 h-10 object-contain"
              />
              <span className="text-xl font-bold text-cream tracking-tight">Fixgo</span>
            </div>
            <p className="text-cream/60 text-sm leading-relaxed max-w-xs">
              Uyingiz uchun barcha xizmatlar — bir bosishda. Tekshirilgan ustalar, shaffof narx.
            </p>
          </FadeIn>

          {/* Services */}
          <FadeIn delay={0.1}>
            <h4 className="text-cream font-semibold text-sm uppercase tracking-wider mb-4">{t("nav_services")}</h4>
            <ul className="space-y-2">
              {["svc_plumbing", "svc_electrical", "svc_cleaning", "svc_ac", "svc_furniture", "svc_painting"].map((key) => (
                <li key={key}>
                  <a href="#services" className="text-cream/60 hover:text-cream text-sm transition-colors duration-200">
                    {t(key)}
                  </a>
                </li>
              ))}
            </ul>
          </FadeIn>

          {/* Company */}
          <FadeIn delay={0.2}>
            <h4 className="text-cream font-semibold text-sm uppercase tracking-wider mb-4">{t("footer_company")}</h4>
            <ul className="space-y-2">
              <li><span className="text-cream/60 text-sm">{t("footer_about")}</span></li>
              <li><span className="text-cream/60 text-sm">{t("footer_careers")}</span></li>
              <li><span className="text-cream/60 text-sm">{t("footer_blog")}</span></li>
            </ul>

            <h4 className="text-cream font-semibold text-sm uppercase tracking-wider mt-8 mb-4">{t("footer_cities")}</h4>
            <ul className="space-y-2">
              {cities.map((city) => (
                <li key={city}>
                  <span className="text-cream/60 text-sm">{city}</span>
                </li>
              ))}
            </ul>
          </FadeIn>

          {/* Contact */}
          <FadeIn delay={0.3}>
            <h4 className="text-cream font-semibold text-sm uppercase tracking-wider mb-4">{t("nav_contact")}</h4>
            <ul className="space-y-3">
              <li>
                <a href="tel:+998901234567" className="flex items-center gap-2 text-cream/60 hover:text-cream text-sm transition-colors duration-200" data-event="whatsapp_click">
                  <Phone className="w-4 h-4" />
                  +998 90 123 45 67
                </a>
              </li>
              <li>
                <a href="mailto:info@fixgo.uz" className="flex items-center gap-2 text-cream/60 hover:text-cream text-sm transition-colors duration-200">
                  <Mail className="w-4 h-4" />
                  info@fixgo.uz
                </a>
              </li>
            </ul>

            <div className="flex items-center gap-3 mt-6">
              <a
                href="https://t.me/fixgo"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-cream hover:bg-white/20 transition-colors"
                data-event="telegram_click"
              >
                <Send className="w-4 h-4" />
              </a>
              <a
                href="https://wa.me/998901234567"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-cream hover:bg-white/20 transition-colors"
                data-event="whatsapp_click"
              >
                <MessageCircle className="w-4 h-4" />
              </a>
            </div>
          </FadeIn>
        </div>

        {/* Bottom bar */}
        <div className="mt-16 pt-8 border-t border-cream/10 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-cream/40 text-xs">
            © 2024 Fixgo. {t("footer_rights")}.
          </p>
          <div className="flex items-center gap-6">
            <span className="text-cream/40 text-xs">{t("footer_privacy")}</span>
            <span className="text-cream/40 text-xs">{t("footer_terms")}</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
