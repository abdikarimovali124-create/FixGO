import { motion } from "framer-motion";
import FadeIn from "./FadeIn";
import ViewJobButton from "./ViewJobButton";
import { useLanguage } from "@/contexts/LanguageContext";
import { Star } from "lucide-react";
import { toast } from "sonner";

const jobs = [
  {
    category: "Santexnika",
    area: "Chilonzor",
    rating: 4.9,
    images: [
      "https://images.unsplash.com/photo-1585704032915-c3400ca199e7?w=600&q=80",
      "https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=600&q=80",
    ],
  },
  {
    category: "Elektrik",
    area: "Yakkasaroy",
    rating: 4.8,
    images: [
      "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=600&q=80",
      "https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=600&q=80",
    ],
  },
  {
    category: "Tozalash",
    area: "Mirzo Ulug'bek",
    rating: 4.7,
    images: [
      "https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=600&q=80",
      "https://images.unsplash.com/photo-1585704032915-c3400ca199e7?w=600&q=80",
    ],
  },
];

export default function FeaturedJobsSection() {
  const { t } = useLanguage();

  return (
    <section id="jobs" className="bg-charcoal rounded-t-[60px] -mt-14 relative z-10 py-24 px-6">
      <div className="max-w-4xl mx-auto">
        <FadeIn>
          <h2
            className="hero-heading font-bold uppercase tracking-tight text-center mb-16"
            style={{ fontSize: "clamp(2rem, 8vw, 5rem)" }}
          >
            {t("jobs_heading")}
          </h2>
        </FadeIn>

        <div className="space-y-8">
          {jobs.map((job, index) => {
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "50px" }}
                transition={{ duration: 0.6, delay: index * 0.15, ease: [0.25, 0.1, 0.25, 1] }}
                className="relative bg-[#2A2925] rounded-[48px] md:rounded-[60px] overflow-hidden border border-white/5"
              >
                {/* Header */}
                <div className="flex items-center justify-between px-6 md:px-10 py-5">
                  <div className="flex items-center gap-4">
                    <span className="text-xs font-bold uppercase tracking-widest text-olive-light bg-olive/20 px-3 py-1 rounded-full">
                      {job.category}
                    </span>
                    <span className="text-white/60 text-sm">{job.area}</span>
                    <div className="flex items-center gap-1">
                      <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                      <span className="text-white/60 text-sm">{job.rating}</span>
                    </div>
                  </div>
                  <ViewJobButton
                    label={t("jobs_view")}
                    onClick={() => toast.info("Xizmat tez orada qo'shiladi")}
                  />
                </div>

                {/* Image Grid */}
                <div className="grid grid-cols-2 gap-2 px-6 md:px-10 pb-6">
                  {job.images.map((img, i) => (
                    <div key={i} className="rounded-2xl md:rounded-3xl overflow-hidden aspect-[4/3]">
                      <img
                        src={img}
                        alt={`${job.category} job ${i + 1}`}
                        className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                        loading="lazy"
                      />
                    </div>
                  ))}
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
