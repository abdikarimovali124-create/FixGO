import { motion, AnimatePresence } from "framer-motion";
import { useBooking } from "@/contexts/BookingContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { X, CheckCircle2, Loader2, MapPin, CalendarClock } from "lucide-react";
import { useEffect, useState } from "react";
import { useNotification } from "@/contexts/NotificationContext";

const services = [
  { key: "plumbing", label_key: "svc_plumbing" },
  { key: "electrical", label_key: "svc_electrical" },
  { key: "cleaning", label_key: "svc_cleaning" },
  { key: "ac", label_key: "svc_ac" },
  { key: "furniture", label_key: "svc_furniture" },
  { key: "painting", label_key: "svc_painting" },
];

const mockPros = [
  { name: "Abdulla", rating: 4.9, eta: "25 min", avatar: "A" },
  { name: "Jamshid", rating: 4.8, eta: "32 min", avatar: "J" },
  { name: "Sardor", rating: 4.7, eta: "18 min", avatar: "S" },
];

export default function BookingModal() {
  const { isOpen, closeBooking, step, setStep, data, setData } = useBooking();
  const { t } = useLanguage();
  const { addNotification } = useNotification();
  const [findingIndex, setFindingIndex] = useState(0);
  const [foundPro] = useState(mockPros[Math.floor(Math.random() * mockPros.length)]);

  useEffect(() => {
    if (step !== "finding") return;
    const interval = setInterval(() => {
      setFindingIndex((prev) => (prev + 1) % mockPros.length);
    }, 1200);
    return () => clearInterval(interval);
  }, [step]);

  // Trigger notification when booking is confirmed
  useEffect(() => {
    if (step !== "confirmed") return;
    addNotification({
      type: "success",
      title: "Buyurtma tasdiqlandi!",
      message: `${data.service ? t(data.service) : "Xizmat"} buyurtmangiz qabul qilindi. ${foundPro.name} sizga ${foundPro.eta} ichida yetib boradi.`,
    });
  }, [step]);

  const steps: { key: string; label: string }[] = [
    { key: "service", label: t("booking_select_service") },
    { key: "address", label: t("booking_address") },
    { key: "datetime", label: t("booking_datetime") },
    { key: "confirm", label: t("booking_confirm") },
  ];

  const currentStepIndex = ["service", "address", "datetime", "confirm", "finding", "confirmed"].indexOf(step);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 z-[100] flex items-center justify-center p-4"
        >
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-charcoal/40 backdrop-blur-sm"
            onClick={closeBooking}
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ duration: 0.3, ease: [0.23, 1, 0.32, 1] }}
            className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl shadow-charcoal/10 overflow-hidden"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-5 border-b border-charcoal/10">
              <h3 className="text-lg font-semibold text-charcoal">{t("booking_title")}</h3>
              <button
                onClick={closeBooking}
                className="w-8 h-8 rounded-full flex items-center justify-center text-charcoal-muted hover:text-charcoal hover:bg-cream transition-colors"
                aria-label="Close"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Progress */}
            {(step === "service" || step === "address" || step === "datetime" || step === "confirm") && (
              <div className="px-6 py-3">
                <div className="flex gap-2">
                  {steps.map((s, i) => (
                    <div
                      key={s.key}
                      className={`h-1 flex-1 rounded-full transition-colors duration-300 ${
                        i <= currentStepIndex ? "bg-olive" : "bg-cream"
                      }`}
                    />
                  ))}
                </div>
                <p className="text-xs text-charcoal-muted mt-2">{steps[currentStepIndex]?.label}</p>
              </div>
            )}

            {/* Content */}
            <div className="px-6 py-6">
              {step === "service" && (
                <div className="grid gap-3">
                  {services.map((svc) => (
                    <button
                      key={svc.key}
                      onClick={() => {
                        setData({ service: svc.label_key });
                        setStep("address");
                      }}
                      className={`w-full text-left px-5 py-4 rounded-2xl border transition-all duration-200 hover:border-olive hover:bg-olive/5 ${
                        data.service === svc.label_key ? "border-olive bg-olive/5" : "border-charcoal/10"
                      }`}
                    >
                      <span className="text-charcoal font-medium">{t(svc.label_key)}</span>
                    </button>
                  ))}
                </div>
              )}

              {step === "address" && (
                <div className="space-y-4">
                  <div className="relative">
                    <MapPin className="absolute left-4 top-4 w-5 h-5 text-charcoal-muted" />
                    <input
                      type="text"
                      placeholder="Manzil kiriting..."
                      value={data.address}
                      onChange={(e) => setData({ address: e.target.value })}
                      className="w-full pl-12 pr-4 py-4 rounded-2xl border border-charcoal/15 bg-cream/30 text-charcoal placeholder:text-charcoal-muted/50 focus:outline-none focus:border-olive focus:ring-1 focus:ring-olive transition-colors"
                    />
                  </div>
                  <div className="flex gap-3">
                    <button
                      onClick={() => setStep("service")}
                      className="flex-1 py-3 rounded-2xl border border-charcoal/15 text-charcoal font-medium hover:bg-cream transition-colors"
                    >
                      {t("booking_back")}
                    </button>
                    <button
                      onClick={() => data.address && setStep("datetime")}
                      disabled={!data.address}
                      className="flex-[2] py-3 rounded-2xl cta-gradient text-white font-medium disabled:opacity-40 transition-opacity"
                    >
                      {t("booking_next")}
                    </button>
                  </div>
                </div>
              )}

              {step === "datetime" && (
                <div className="space-y-4">
                  <div className="relative">
                    <CalendarClock className="absolute left-4 top-4 w-5 h-5 text-charcoal-muted" />
                    <input
                      type="datetime-local"
                      value={data.date}
                      onChange={(e) => setData({ date: e.target.value })}
                      className="w-full pl-12 pr-4 py-4 rounded-2xl border border-charcoal/15 bg-cream/30 text-charcoal focus:outline-none focus:border-olive focus:ring-1 focus:ring-olive transition-colors"
                    />
                  </div>
                  <div className="flex gap-3">
                    <button
                      onClick={() => setStep("address")}
                      className="flex-1 py-3 rounded-2xl border border-charcoal/15 text-charcoal font-medium hover:bg-cream transition-colors"
                    >
                      {t("booking_back")}
                    </button>
                    <button
                      onClick={() => data.date && setStep("confirm")}
                      disabled={!data.date}
                      className="flex-[2] py-3 rounded-2xl cta-gradient text-white font-medium disabled:opacity-40 transition-opacity"
                    >
                      {t("booking_next")}
                    </button>
                  </div>
                </div>
              )}

              {step === "confirm" && (
                <div className="space-y-5">
                  <div className="bg-cream/50 rounded-2xl p-5 space-y-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-charcoal-muted">Xizmat</span>
                      <span className="text-charcoal font-medium">{t(data.service)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-charcoal-muted">{t("booking_address")}</span>
                      <span className="text-charcoal font-medium">{data.address}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-charcoal-muted">{t("booking_datetime")}</span>
                      <span className="text-charcoal font-medium">{data.date}</span>
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <button
                      onClick={() => setStep("datetime")}
                      className="flex-1 py-3 rounded-2xl border border-charcoal/15 text-charcoal font-medium hover:bg-cream transition-colors"
                    >
                      {t("booking_back")}
                    </button>
                    <button
                      onClick={() => setStep("finding")}
                      className="flex-[2] py-3 rounded-2xl cta-gradient text-white font-medium transition-opacity hover:opacity-90"
                    >
                      {t("booking_confirm")}
                    </button>
                  </div>
                </div>
              )}

              {step === "finding" && (
                <div className="flex flex-col items-center py-8 space-y-6">
                  <div className="w-16 h-16 rounded-full bg-olive/10 flex items-center justify-center">
                    <Loader2 className="w-8 h-8 text-olive animate-spin" />
                  </div>
                  <div className="text-center">
                    <p className="text-charcoal font-medium text-lg">{t("booking_finding")}</p>
                    <div className="flex items-center justify-center gap-2 mt-3 bg-cream/50 rounded-xl px-4 py-2">
                      <span className="w-6 h-6 rounded-full bg-olive/20 flex items-center justify-center text-xs font-bold text-olive">
                        {mockPros[findingIndex].avatar}
                      </span>
                      <span className="text-sm text-charcoal">{mockPros[findingIndex].name}</span>
                      <span className="text-xs text-charcoal-muted">· {mockPros[findingIndex].eta}</span>
                    </div>
                  </div>
                </div>
              )}

              {step === "confirmed" && (
                <div className="flex flex-col items-center py-8 space-y-5">
                  <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center">
                    <CheckCircle2 className="w-8 h-8 text-green-600" />
                  </div>
                  <p className="text-charcoal font-semibold text-xl">{t("booking_confirmed")}</p>
                  <div className="bg-cream/50 rounded-2xl p-5 w-full flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-olive/20 flex items-center justify-center text-lg font-bold text-olive">
                      {foundPro.avatar}
                    </div>
                    <div className="flex-1">
                      <p className="text-charcoal font-medium">{foundPro.name}</p>
                      <div className="flex items-center gap-2 text-sm text-charcoal-muted">
                        <span>{foundPro.rating}★</span>
                        <span>·</span>
                        <span>ETA: {foundPro.eta}</span>
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={closeBooking}
                    className="w-full py-3 rounded-2xl cta-gradient text-white font-medium transition-opacity hover:opacity-90"
                  >
                    Yaxshi
                  </button>
                </div>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
