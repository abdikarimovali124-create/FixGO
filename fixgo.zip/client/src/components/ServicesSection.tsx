import { useState } from "react";
import FadeIn from "./FadeIn";
import BookServiceButton from "./BookServiceButton";
import { useLanguage } from "@/contexts/LanguageContext";
import { useNotification } from "@/contexts/NotificationContext";
import {
  Wrench, Zap, SprayCan, Flame, Sofa, Palette, Search,
  Cog, Truck, TreePine, Bug, Hammer, Home, Baby,
  Heart, Key, Mountain, ThermometerSun, Wifi, DoorOpen,
  UserCheck, GraduationCap, Sparkles, ChefHat, ShieldCheck
} from "lucide-react";

const serviceIcons: Record<string, any> = {
  plumbing: Wrench,
  electrical: Zap,
  cleaning: SprayCan,
  ac: Flame,
  furniture: Sofa,
  painting: Palette,
  appliance_repair: Cog,
  moving: Truck,
  gardening: TreePine,
  pest_control: Bug,
  carpentry: Hammer,
  renovation: Home,
  childcare: Baby,
  elderly_care: Heart,
  locksmith: Key,
  roofing: Mountain,
  water_heater: ThermometerSun,
  internet_tv: Wifi,
  window: DoorOpen,
  handyman: Wrench,
  tutor: GraduationCap,
  beauty: Sparkles,
  cooking: ChefHat,
  security: ShieldCheck,
};

const prices: Record<string, string> = {
  plumbing: "50,000",
  electrical: "60,000",
  cleaning: "40,000",
  ac: "80,000",
  furniture: "70,000",
  painting: "90,000",
  appliance_repair: "100,000",
  moving: "200,000",
  gardening: "45,000",
  pest_control: "120,000",
  carpentry: "80,000",
  renovation: "500,000",
  childcare: "35,000",
  elderly_care: "50,000",
  locksmith: "70,000",
  roofing: "150,000",
  water_heater: "90,000",
  internet_tv: "60,000",
  window: "120,000",
  handyman: "40,000",
  tutor: "45,000",
  beauty: "55,000",
  cooking: "80,000",
  security: "250,000",
};

const categories = [
  { label: "Barchasi", filter: "all" },
  { label: "Ta'mirlash", filter: "repair" },
  { label: "Tozalash", filter: "cleaning" },
  { label: "Qurilish", filter: "construction" },
  { label: "Parvarish", filter: "care" },
  { label: "Boshqa", filter: "other" },
];

const categoryMap: Record<string, string[]> = {
  repair: ["plumbing", "electrical", "ac", "appliance_repair", "water_heater", "internet_tv"],
  cleaning: ["cleaning", "pest_control"],
  construction: ["painting", "carpentry", "renovation", "roofing", "window", "handyman"],
  care: ["childcare", "elderly_care", "tutor", "beauty", "cooking"],
  other: ["furniture", "moving", "gardening", "locksmith", "security"],
};

export default function ServicesSection() {
  const { t, language } = useLanguage();
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");

  const allServices = [
    { key: "plumbing", cat: "repair" },
    { key: "electrical", cat: "repair" },
    { key: "cleaning", cat: "cleaning" },
    { key: "ac", cat: "repair" },
    { key: "furniture", cat: "other" },
    { key: "painting", cat: "construction" },
    { key: "appliance_repair", cat: "repair" },
    { key: "moving", cat: "other" },
    { key: "gardening", cat: "other" },
    { key: "pest_control", cat: "cleaning" },
    { key: "carpentry", cat: "construction" },
    { key: "renovation", cat: "construction" },
    { key: "childcare", cat: "care" },
    { key: "elderly_care", cat: "care" },
    { key: "locksmith", cat: "other" },
    { key: "roofing", cat: "construction" },
    { key: "water_heater", cat: "repair" },
    { key: "internet_tv", cat: "repair" },
    { key: "window", cat: "construction" },
    { key: "handyman", cat: "construction" },
    { key: "tutor", cat: "care" },
    { key: "beauty", cat: "care" },
    { key: "cooking", cat: "care" },
    { key: "security", cat: "other" },
  ];

  const filtered = allServices
    .filter((s) => activeCategory === "all" || categoryMap[activeCategory]?.includes(s.key))
    .filter((s) => {
      const name = t(`svc_${s.key}`).toLowerCase();
      const desc = t(`svc_${s.key}_desc`).toLowerCase();
      const q = searchQuery.toLowerCase();
      return name.includes(q) || desc.includes(q);
    });

  const catLabels: Record<string, string> = {
    Barchasi: "Barchasi",
    "Ta'mirlash": language === "ru" ? "Ремонт" : language === "en" ? "Repair" : "Ta'mirlash",
    Tozalash: language === "ru" ? "Уборка" : language === "en" ? "Cleaning" : "Tozalash",
    Qurilish: language === "ru" ? "Строительство" : language === "en" ? "Construction" : "Qurilish",
    Parvarish: language === "ru" ? "Уход" : language === "en" ? "Care" : "Parvarish",
    Boshqa: language === "ru" ? "Другое" : language === "en" ? "Other" : "Boshqa",
  };

  return (
    <section id="services" className="bg-white rounded-t-[60px] -mt-10 relative z-10 py-24 px-6">
      <div className="max-w-5xl mx-auto">
        <FadeIn>
          <h2
            className="font-bold uppercase tracking-tight text-center mb-4"
            style={{ fontSize: "clamp(2rem, 10vw, 6rem)", color: "#1F1E1B" }}
          >
            {t("categories_heading")}
          </h2>
          <p className="text-center text-charcoal-muted mb-10 text-sm md:text-base">
            {t("categories_subheading")}
          </p>
        </FadeIn>

        {/* Search bar */}
        <FadeIn delay={0.1} className="mb-8">
          <div className="relative max-w-md mx-auto">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-charcoal-muted" />
            <input
              type="text"
              placeholder={language === "ru" ? "Поиск услуг..." : language === "en" ? "Search services..." : "Xizmat qidirish..."}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3.5 rounded-full border border-charcoal/10 bg-cream/30 text-charcoal placeholder:text-charcoal-muted/50 focus:outline-none focus:border-olive focus:ring-1 focus:ring-olive transition-colors"
            />
          </div>
        </FadeIn>

        {/* Category filter tabs */}
        <FadeIn delay={0.15} className="mb-10">
          <div className="flex items-center justify-center gap-2 flex-wrap">
            {categories.map((cat) => (
              <button
                key={cat.filter}
                onClick={() => setActiveCategory(cat.filter)}
                className={`px-4 py-2 rounded-full text-xs font-medium transition-all duration-200 ${
                  activeCategory === cat.filter
                    ? "bg-olive text-white shadow-md shadow-olive/20"
                    : "bg-cream/50 text-charcoal-muted hover:bg-cream hover:text-charcoal"
                }`}
              >
                {catLabels[cat.label]}
              </button>
            ))}
          </div>
        </FadeIn>

        <div className="space-y-0">
          {filtered.map((service, i) => {
            const Icon = serviceIcons[service.key];
            return (
              <FadeIn key={service.key} delay={i * 0.05}>
                <div className="group flex items-center gap-4 md:gap-8 py-5 border-b border-charcoal/[0.06] hover:bg-cream/30 rounded-2xl px-4 -mx-4 transition-colors duration-200">
                  <span
                    className="font-black text-charcoal/10 group-hover:text-charcoal/20 transition-colors"
                    style={{ fontSize: "clamp(1.8rem, 6vw, 100px)", lineHeight: 1 }}
                  >
                    {String(i + 1).padStart(2, "0")}
                  </span>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3 mb-1">
                      <Icon className="w-5 h-5 text-olive flex-shrink-0" />
                      <h3 className="text-charcoal font-medium uppercase tracking-wide text-sm md:text-base">
                        {t(`svc_${service.key}`)}
                      </h3>
                    </div>
                    <p className="text-charcoal-muted font-light text-xs md:text-sm">{t(`svc_${service.key}_desc`)}</p>
                  </div>

                  <div className="flex items-center gap-3 flex-shrink-0">
                    <span className="text-olive text-xs font-medium hidden md:inline">
                      {t("svc_from")} {prices[service.key]} {t("svc_price")}
                    </span>
                    <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                      <BookServiceButton
                        service={service.key}
                        label={t("svc_order")}
                        size="sm"
                        dataEvent="service_select"
                      />
                    </div>
                  </div>
                </div>
              </FadeIn>
            );
          })}
        </div>

        {filtered.length === 0 && (
          <p className="text-center text-charcoal-muted py-12">
            {language === "ru" ? "Ничего не найдено" : language === "en" ? "Nothing found" : "Hech narsa topilmadi"}
          </p>
        )}
      </div>
    </section>
  );
}
