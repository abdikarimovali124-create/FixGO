import { createContext, useContext, useState, useCallback, type ReactNode } from "react";

export type BookingStep = "service" | "address" | "datetime" | "confirm" | "finding" | "confirmed";

interface BookingData {
  service: string;
  address: string;
  date: string;
  time: string;
}

interface BookingContextType {
  isOpen: boolean;
  openBooking: (service?: string) => void;
  closeBooking: () => void;
  step: BookingStep;
  setStep: (step: BookingStep) => void;
  data: BookingData;
  setData: (data: Partial<BookingData>) => void;
}

const BookingContext = createContext<BookingContextType>({
  isOpen: false,
  openBooking: () => {},
  closeBooking: () => {},
  step: "service",
  setStep: () => {},
  data: { service: "", address: "", date: "", time: "" },
  setData: () => {},
});

export function BookingProvider({ children }: { children: ReactNode }) {
  const [isOpen, setIsOpen] = useState(false);
  const [step, setStep] = useState<BookingStep>("service");
  const [data, setDataState] = useState<BookingData>({ service: "", address: "", date: "", time: "" });

  const openBooking = useCallback((service?: string) => {
    setDataState({ service: service || "", address: "", date: "", time: "" });
    setStep("service");
    setIsOpen(true);
  }, []);

  const closeBooking = useCallback(() => {
    setIsOpen(false);
  }, []);

  const setData = useCallback((partial: Partial<BookingData>) => {
    setDataState(prev => ({ ...prev, ...partial }));
  }, []);

  return (
    <BookingContext.Provider value={{ isOpen, openBooking, closeBooking, step, setStep, data, setData }}>
      {children}
    </BookingContext.Provider>
  );
}

export function useBooking() {
  return useContext(BookingContext);
}
