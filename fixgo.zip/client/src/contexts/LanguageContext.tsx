import { createContext, useContext, useState, useCallback, type ReactNode } from "react";

export type Language = "uz" | "ru" | "en";

const translations: Record<string, Record<Language, string>> = {
  // Nav
  nav_services: { uz: "Xizmatlar", ru: "Услуги", en: "Services" },
  nav_how: { uz: "Qanday ishlaydi", ru: "Как это работает", en: "How it works" },
  nav_pricing: { uz: "Narxlar", ru: "Цены", en: "Pricing" },
  nav_contact: { uz: "Aloqa", ru: "Контакты", en: "Contact" },

  // Hero
  hero_heading: { uz: "Uyingiz uchun barcha xizmatlar — bir bosishda", ru: "Все услуги для дома — в один клик", en: "All home services, one tap away" },
  hero_subtext: { uz: "Tekshirilgan ustalar, shaffof narx, 60 daqiqada uyingizda", ru: "Проверенные мастера, прозрачные цены, у вас дома за 60 минут", en: "Verified pros, transparent pricing, at your door in 60 minutes" },
  hero_cta: { uz: "Xizmat buyurtma qilish", ru: "Заказать услугу", en: "Book a service" },
  floating_service: { uz: "Santexnik · 25 daqiqada yetib boradi", ru: "Сантехник · прибудет через 25 мин", en: "Plumber · arriving in 25 min" },

  // Trust Marquee
  trust_orders: { uz: "10,000+ bajarilgan buyurtma", ru: "10 000+ выполненных заказов", en: "10,000+ completed orders" },
  trust_rating: { uz: "4.9★ o'rtacha reyting", ru: "4.9★ средний рейтинг", en: "4.9★ average rating" },
  trust_workers: { uz: "500+ tekshirilgan usta", ru: "500+ проверенных мастеров", en: "500+ verified professionals" },
  trust_support: { uz: "24/7 qo'llab-quvvatlash", ru: "Поддержка 24/7", en: "24/7 support" },

  // Services — All Categories
  svc_plumbing: { uz: "Santexnika", ru: "Сантехника", en: "Plumbing" },
  svc_plumbing_desc: { uz: "Kran, quvur, unitaz ta'mirlash va o'rnatish", ru: "Ремонт и установка кранов, труб, унитазов", en: "Repair and installation of taps, pipes, toilets" },

  svc_electrical: { uz: "Elektrik", ru: "Электрика", en: "Electrical" },
  svc_electrical_desc: { uz: "Elektr simlari, rozetka, yoritish tizimlari", ru: "Проводка, розетки, системы освещения", en: "Wiring, outlets, lighting systems" },

  svc_cleaning: { uz: "Tozalash", ru: "Уборка", en: "Cleaning" },
  svc_cleaning_desc: { uz: "Umumiy va chuqur tozalash xizmatlari", ru: "Общая и глубокая уборка", en: "General and deep cleaning services" },

  svc_ac: { uz: "Konditsioner va HVAC", ru: "Кондиционер и HVAC", en: "AC & HVAC" },
  svc_ac_desc: { uz: "O'rnatish, texnik xizmat, ta'mirlash, tozalash", ru: "Установка, техобслуживание, ремонт, чистка", en: "Installation, maintenance, repair, cleaning" },

  svc_furniture: { uz: "Mebel yig'ish", ru: "Сборка мебели", en: "Furniture Assembly" },
  svc_furniture_desc: { uz: "IKEA va boshqa mebellarni yig'ish va o'rnatish", ru: "Сборка и установка IKEA и другой мебели", en: "Assembly and installation of IKEA and other furniture" },

  svc_painting: { uz: "Bo'yoq ishlari", ru: "Покраска", en: "Painting" },
  svc_painting_desc: { uz: "Xona va fasad bo'yash xizmatlari", ru: "Покраска комнат и фасадов", en: "Room and facade painting services" },

  svc_appliance_repair: { uz: "Maishiy texnika ta'miri", ru: "Ремонт бытовой техники", en: "Appliance Repair" },
  svc_appliance_repair_desc: { uz: "Kir mashinasi, muzlatgich, kir yuvish mashinasi, plita ta'miri", ru: "Ремонт стиральных машин, холодильников, посудомоечных машин, плит", en: "Repair of washing machines, refrigerators, dishwashers, ovens" },

  svc_moving: { uz: "Ko'chish va yuk tashish", ru: "Переезд и грузоперевозки", en: "Moving & Relocation" },
  svc_moving_desc: { uz: "Uydan uyga ko'chish, yuk tashish, qadoqlash xizmatlari", ru: "Переезд из дома в дом, грузоперевозки, упаковка", en: "House-to-house moving, cargo transport, packing services" },

  svc_gardening: { uz: "Bog'bonchilik va obodonlashtirish", ru: "Садоводство и благоустройство", en: "Gardening & Landscaping" },
  svc_gardening_desc: { uz: "O't o'rish, daraxt kesish, gullarni parvarish qilish, tomorqa ishlari", ru: "Стрижка газона, обрезка деревьев, уход за цветами, огород", en: "Lawn mowing, tree trimming, flower care, garden maintenance" },

  svc_pest_control: { uz: "Zararkunandalarga qarshi kurash", ru: "Борьба с вредителями", en: "Pest Control" },
  svc_pest_control_desc: { uz: "Hasharotlar, kemiruvchilar va boshqa zararkunandalarga qarshi", ru: "Борьба с насекомыми, грызунами и другими вредителями", en: "Treatment against insects, rodents and other pests" },

  svc_carpentry: { uz: "Duradgorchilik", ru: "Столярные работы", en: "Carpentry" },
  svc_carpentry_desc: { uz: "Eshik, deraza, shkaf, pol ta'miri va yasash", ru: "Ремонт и изготовление дверей, окон, шкафов, полов", en: "Repair and crafting of doors, windows, cabinets, floors" },

  svc_renovation: { uz: "Uy ta'mirlash", ru: "Ремонт дома", en: "Home Renovation" },
  svc_renovation_desc: { uz: "Kosmetika va kapital ta'mir, yopqich, kafel, gipsokarton", ru: "Косметический и капитальный ремонт, штукатурка, плитка, гипсокартон", en: "Cosmetic and full renovation, plastering, tiling, drywall" },

  svc_childcare: { uz: "Bolalar parvarishi", ru: "Уход за детьми", en: "Babysitting & Childcare" },
  svc_childcare_desc: { uz: "Tajribali bolabop, uy ishlari va mashg'ulotlar", ru: "Опытная няня, помощь с уроками и занятиями", en: "Experienced nanny, homework help and activities" },

  svc_elderly_care: { uz: "Keksalar parvarishi", ru: "Уход за пожилыми", en: "Elderly Care" },
  svc_elderly_care_desc: { uz: "Kundalik yordam, dori qabul qilish, sog'liq monitoringi", ru: "Ежедневная помощь, приём лекарств, мониторинг здоровья", en: "Daily assistance, medication, health monitoring" },

  svc_locksmith: { uz: "Qulfgar", ru: "Слесарь-замочник", en: "Locksmith" },
  svc_locksmith_desc: { uz: "Qulf ochish, almashtirish, xavfsizlik tizimlari", ru: "Вскрытие замков, замена, системы безопасности", en: "Lock opening, replacement, security systems" },

  svc_roofing: { uz: "Tom qurilishi va ta'miri", ru: "Крыша и кровля", en: "Roofing" },
  svc_roofing_desc: { uz: "Tom yopish, ta'mirlash, gidroizolyatsiya", ru: "Укладка кровли, ремонт, гидроизоляция", en: "Roof installation, repair, waterproofing" },

  svc_water_heater: { uz: "Suv isitgich", ru: "Водонагреватель", en: "Water Heater" },
  svc_water_heater_desc: { uz: "O'rnatish, ta'mirlash, texnik xizmat ko'rsatish", ru: "Установка, ремонт, техобслуживание", en: "Installation, repair, maintenance" },

  svc_internet_tv: { uz: "Internet va televideniye", ru: "Интернет и ТВ", en: "Internet & TV" },
  svc_internet_tv_desc: { uz: "Internet o'rnatish, kabel tortish, antenalar", ru: "Установка интернета, прокладка кабеля, антенны", en: "Internet setup, cable routing, antennas" },

  svc_window: { uz: "Deraza va eshik", ru: "Окна и двери", en: "Windows & Doors" },
  svc_window_desc: { uz: "Deraza almashtirish, balkon, eshik o'rnatish", ru: "Замена окон, балконы, установка дверей", en: "Window replacement, balconies, door installation" },

  svc_handyman: { uz: "Usta (har xil ishlar)", ru: "Мастер на все руки", en: "Handyman" },
  svc_handyman_desc: { uz: "Kichik ta'mirlar, devorga osish, mebel sozlash", ru: "Мелкий ремонт, навеска, настройка мебели", en: "Small repairs, mounting, furniture adjustment" },

  svc_tutor: { uz: "Repetitor va o'qituvchi", ru: "Репетитор", en: "Tutoring" },
  svc_tutor_desc: { uz: "Matematika, fizika, ingliz tili va boshqa fanlar", ru: "Математика, физика, английский язык и другие предметы", en: "Math, physics, English language and other subjects" },

  svc_beauty: { uz: "Go'zallik va salomatlik", ru: "Красота и здоровье", en: "Beauty & Wellness" },
  svc_beauty_desc: { uz: "Soch to'ldirish, manikyur, massaj uyi", ru: "Укладка волос, маникюр, массаж на дому", en: "Hair styling, manicure, home massage" },

  svc_cooking: { uz: "Oshpazlik", ru: "Кулинария", en: "Cooking" },
  svc_cooking_desc: { uz: "Tadbirlar uchun oshpaz, kundalik ovqat tayyorlash", ru: "Повар на мероприятия, ежедневное приготовление еды", en: "Chef for events, daily meal preparation" },

  svc_security: { uz: "Xavfsizlik va kuzatuv", ru: "Безопасность и видеонаблюдение", en: "Security & CCTV" },
  svc_security_desc: { uz: "Video kuzatuv tizimi, signalizatsiya o'rnatish", ru: "Установка систем видеонаблюдения, сигнализации", en: "CCTV installation, alarm systems setup" },

  // Common
  svc_order: { uz: "Buyurtma berish", ru: "Заказать", en: "Book Now" },
  svc_from: { uz: "dan", ru: "от", en: "from" },
  svc_price: { uz: "so'm", ru: "сум", en: "so'm" },

  // About
  about_heading: { uz: "Fixgo haqida", ru: "О Fixgo", en: "About Fixgo" },
  about_text: { uz: "Biz uy egalarini tekshirilgan mutaxassislar bilan bog'laymiz — santexnikdan tortib to tozalashgacha, barchasi bir ilovada, shaffof narx va kafolat bilan.", ru: "Мы соединяем владельцев домов с проверенными специалистами — от сантехники до уборки, всё в одном приложении, с прозрачными ценами и гарантией.", en: "We connect homeowners with verified professionals — from plumbing to cleaning, all in one app, with transparent pricing and a satisfaction guarantee." },

  // How it works
  hiw_heading: { uz: "Qanday ishlaydi", ru: "Как это работает", en: "How it works" },
  hiw_step1: { uz: "Tanlang", ru: "Выберите", en: "Choose" },
  hiw_step1_desc: { uz: "Kerakli xizmat turini tanlang", ru: "Выберите нужный тип услуги", en: "Select the service you need" },
  hiw_step2: { uz: "Band qiling", ru: "Запишитесь", en: "Schedule" },
  hiw_step2_desc: { uz: "Vaqt va manzilni belgilang", ru: "Укажите время и адрес", en: "Set time and address" },
  hiw_step3: { uz: "Usta tasdiqlaydi", ru: "Мастер подтверждает", en: "Pro confirms" },
  hiw_step3_desc: { uz: "O'rtacha 28 daqiqada tasdiqlanadi", ru: "Подтверждение в среднем за 28 минут", en: "Confirmed in about 28 minutes" },
  hiw_step4: { uz: "Ish bajariladi", ru: "Работа выполнена", en: "Job completed" },
  hiw_step4_desc: { uz: "Baholang va to'lov qiling", ru: "Оцените и оплатите", en: "Rate and pay" },

  // Featured Jobs
  jobs_heading: { uz: "Bajarilgan ishlar", ru: "Выполненные работы", en: "Recent Jobs" },
  jobs_view: { uz: "Batafsil", ru: "Подробнее", en: "View job" },

  // Pricing
  pricing_heading: { uz: "Narxlar", ru: "Цены", en: "Pricing" },
  pricing_cta: { uz: "Hoziroq usta chaqiring", ru: "Вызвать мастера сейчас", en: "Book a pro now" },
  pricing_app: { uz: "Ilovani yuklab olish", ru: "Скачать приложение", en: "Download the app" },
  pricing_standard: { uz: "Standart", ru: "Стандарт", en: "Standard" },
  pricing_fast: { uz: "Tezkor", ru: "Быстрый", en: "Express" },
  pricing_premium: { uz: "Premium", ru: "Премиум", en: "Premium" },

  // Footer
  footer_company: { uz: "Kompaniya", ru: "Компания", en: "Company" },
  footer_about: { uz: "Biz haqimizda", ru: "О нас", en: "About" },
  footer_careers: { uz: "Bo'sh ish o'rinlari", ru: "Карьера", en: "Careers" },
  footer_blog: { uz: "Blog", ru: "Блог", en: "Blog" },
  footer_cities: { uz: "Shaharlar", ru: "Города", en: "Cities" },
  footer_privacy: { uz: "Maxfiylik", ru: "Конфиденциальность", en: "Privacy" },
  footer_terms: { uz: "Shartlar", ru: "Условия", en: "Terms" },
  footer_rights: { uz: "Barcha huquqlar himoyalangan", ru: "Все права защищены", en: "All rights reserved" },

  // Booking
  booking_title: { uz: "Xizmat buyurtma qilish", ru: "Заказать услугу", en: "Book a service" },
  booking_select_service: { uz: "Xizmat turini tanlang", ru: "Выберите тип услуги", en: "Select a service" },
  booking_address: { uz: "Manzil kiriting", ru: "Введите адрес", en: "Enter address" },
  booking_datetime: { uz: "Sana va vaqtni tanlang", ru: "Выберите дату и время", en: "Select date & time" },
  booking_confirm: { uz: "Tasdiqlash", ru: "Подтвердить", en: "Confirm" },
  booking_finding: { uz: "Usta topilmoqda...", ru: "Поиск мастера...", en: "Finding a pro..." },
  booking_confirmed: { uz: "Tasdiqlandi!", ru: "Подтверждено!", en: "Confirmed!" },
  booking_next: { uz: "Keyingi", ru: "Далее", en: "Next" },
  booking_back: { uz: "Orqaga", ru: "Назад", en: "Back" },

  // FAQ
  faq_heading: { uz: "Ko'p so'raladigan savollar", ru: "Часто задаваемые вопросы", en: "Frequently Asked Questions" },
  faq1_q: { uz: "To'lov qanday amalga oshadi?", ru: "Как происходит оплата?", en: "How does payment work?" },
  faq1_a: { uz: "Naqd pul yoki ilova orqali to'lash mumkin. Xizmat tugagandan so'ng usta narxni ko'rsatadi, siz tasdiqlaysiz.", ru: "Можно оплатить наличными или через приложение. После завершения работы мастер показывает стоимость, вы подтверждаете.", en: "Pay in cash or via the app. After the job, the pro shows the price and you confirm." },
  faq2_q: { uz: "Kafolat qancha?", ru: "Какая гарантия?", en: "What is the guarantee?" },
  faq2_a: { uz: "Barcha xizmatlarga 30 kunlik kafolat beriladi. Agar muammo takrorlansa, bepul tuzatamiz.", ru: "На все услуги даётся 30-дневная гарантия. Если проблема повторится — бесплатно исправим.", en: "All services come with a 30-day guarantee. If the issue returns, we fix it free." },
  faq3_q: { uz: "Qaysi shaharlarda ishlaydi?", ru: "В каких городах работаете?", en: "Which cities do you serve?" },
  faq3_a: { uz: "Hozirda Toshkent shahrida ishlaymiz. Tez orada Samarqand, Buxoro va boshqa shaharlarga kengayamiz.", ru: "Сейчас работаем в Ташкенте. Скоро расширимся в Самарканд, Бухару и другие города.", en: "Currently serving Tashkent. Expanding to Samarkand, Bukhara, and more soon." },
  faq4_q: { uz: "Ustalar qanday tekshiriladi?", ru: "Как проверяются мастера?", en: "How are pros verified?" },
  faq4_a: { uz: "Har bir usta shaxsiy tekshiruvi, tajribasi va mijozlarning baxolarini asosida tekshiriladi.", ru: "Каждый мастер проходит проверку документов, опыта и отзывов клиентов.", en: "Every pro is verified through ID checks, experience validation, and customer reviews." },

  // Testimonials
  testimonials_heading: { uz: "Mijozlar fikri", ru: "Отзывы клиентов", en: "Customer Reviews" },

  // Categories header
  categories_heading: { uz: "Barcha xizmatlar", ru: "Все услуги", en: "All Services" },
  categories_subheading: { uz: "Uyingiz uchun 20+ xizmat turi — barchasi bir ilovada", ru: "20+ видов услуг для вашего дома — всё в одном приложении", en: "20+ services for your home — all in one app" },
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType>({
  language: "uz",
  setLanguage: () => {},
  t: (key: string) => key,
});

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>("uz");

  const t = useCallback(
    (key: string) => {
      const entry = translations[key];
      if (!entry) return key;
      return entry[language] || entry.uz || key;
    },
    [language]
  );

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  return useContext(LanguageContext);
}
