# Fixgo — Google Play Store Listing

**Author:** Manus AI
**Date:** July 21, 2026

---

## App Title

**Fixgo — Home Services**

---

## Short Description (80 characters max)

**UZ:** Uyingiz uchun 20+ xizmat — tekshirilgan ustalar, shaffof narx, 60 daqiqada.

**RU:** 20+ услуг для дома — проверенные мастера, прозрачные цены, за 60 минут.

**EN:** 20+ home services — verified pros, transparent pricing, at your door in 60 min.

---

## Long Description (4,000 characters max)

**UZ (Uzbek):**

Uyingiz uchun barcha kerakli xizmatlar — bir ilovada!

Fixgo — bu uy egalarini tekshirilgan, tajribali ustalar bilan bog'laydigan O'zbekistondagi birinchi to'liq xizmat platformasi. Santexnikdan tortib to bolabopgacha — 20 dan ortiq xizmat turi bir bosishda mavjud.

Nima uchun Fixgo?

- **Tekshirilgan ustalar.** Har bir mutaxassis shaxsiy hujjatlar, tajriba va mijozlar baholari asosida tekshiriladi.
- **Shaffof narx.** Xizmat oldidan narx ko'rinadi — hech qanday yashirin to'lov yo'q.
- **60 daqiqada.** O'rtacha 28 daqiqada usta yetib boradi, 60 daqiqada ish boshlanadi.
- **30 kunlik kafolat.** Barcha xizmatlarga kafolat — muammo takrorlansa, bepul tuzatamiz.
- **24/7 qo'llab-quvvatlash.** Istalgan vaqtda yordam oling.

Xizmat turlari:

Santexnika | Elektrik | Tozalash | Konditsioner va HVAC | Mebel yig'ish | Bo'yoq ishlari | Maishiy texnika ta'miri | Ko'chish va yuk tashish | Bog'bonchilik | Zararkunandalarga qarshi kurash | Duradgorchilik | Uy ta'mirlash | Bolalar parvarishi | Keksalar parvarishi | Qulfgar | Tom qurilishi | Suv isitgich | Internet va televideniye | Deraza va eshik | Usta (har xil ishlar) | Repetitor | Go'zallik | Oshpazlik | Xavfsizlik va kuzatuv

Qanday ishlaydi:

1. Xizmatni tanlang — 20+ kategoriya orasidan keraklisini tanlang.
2. Vaqt va manzilni belgilang — qachon va qayerda kerakligini ayting.
3. Ustani tanlang — reyting va tajribaga qarab eng yaxshisini tanlang yoki avtomatik tayinlang.
4. Ish bajariladi — usta vaqtida yetib keladi, ishni bajaradi, siz baho berasiz.

Fixgo — uyingiz uchun ishonchli hamkor. Hoziroq yuklab oling!

---

**RU (Russian):**

Все нужные услуги для вашего дома — в одном приложении!

Fixgo — это первая полноценная платформа домашних услуг в Узбекистане, которая соединяет владельцев домов с проверенными и опытными мастерами. От сантехника до няни — более 20 видов услуг в одном нажатии.

Почему Fixgo?

- **Проверенные мастера.** Каждый специалист проходит проверку документов, опыта и отзывов клиентов.
- **Прозрачные цены.** Цена видна до начала работы — никаких скрытых платежей.
- **За 60 минут.** В среднем мастер прибывает за 28 минут, работа начинается в течение 60 минут.
- **Гарантия 30 дней.** На все услуги даётся гарантия — если проблема повторится, исправим бесплатно.
- **Поддержка 24/7.** Получите помощь в любое время.

Виды услуг:

Сантехника | Электрика | Уборка | Кондиционер и HVAC | Сборка мебели | Покраска | Ремонт бытовой техники | Переезд и грузоперевозки | Садоводство | Борьба с вредителями | Столярные работы | Ремонт дома | Уход за детьми | Уход за пожилыми | Слесарь-замочник | Крыша и кровля | Водонагреватель | Интернет и ТВ | Окна и двери | Мастер на все руки | Репетитор | Красота и здоровье | Кулинария | Безопасность и видеонаблюдение

Как это работает:

1. Выберите услугу — из 20+ категорий.
2. Укажите время и адрес — когда и где нужна услуга.
3. Выберите мастера — по рейтингу и опыту или получите автоматически.
4. Работа выполнена — мастер приезжает вовремя, выполняет работу, вы оцениваете.

Fixgo — надёжный партнёр для вашего дома. Скачайте прямо сейчас!

---

**EN (English):**

All the home services you need — in one app!

Fixgo is the first comprehensive home services platform in Uzbekistan that connects homeowners with verified, experienced professionals. From plumbers to babysitters — 20+ service categories in one tap.

Why Fixgo?

- **Verified pros.** Every professional is verified through ID checks, experience validation, and customer reviews.
- **Transparent pricing.** See the price before booking — no hidden fees.
- **In 60 minutes.** Pros arrive in about 28 minutes on average, work starts within 60 minutes.
- **30-day guarantee.** All services come with a guarantee — if the issue returns, we fix it free.
- **24/7 support.** Get help anytime.

Service categories:

Plumbing | Electrical | Cleaning | AC & HVAC | Furniture Assembly | Painting | Appliance Repair | Moving & Relocation | Gardening | Pest Control | Carpentry | Home Renovation | Babysitting & Childcare | Elderly Care | Locksmith | Roofing | Water Heater | Internet & TV | Windows & Doors | Handyman | Tutoring | Beauty & Wellness | Cooking | Security & CCTV

How it works:

1. Choose a service — pick from 20+ categories.
2. Set time and address — tell us when and where you need it.
3. Select a pro — choose by rating and experience or get matched automatically.
4. Job done — the pro arrives on time, completes the work, you rate the experience.

Fixgo — your trusted partner for everything home. Download now!

---

## Content Rating

**Age Rating:** Everyone (PEGI 3)

The app contains no harmful, violent, sexual, or age-restricted content. It is a utility/home services application suitable for all ages.

---

## Category Selection

**Primary Category:** Business

**Secondary Category:** Productivity

**Tags:** home services, handyman, plumber, electrician, cleaning, repair, maintenance, local services, on-demand, Uzbekistan

---

## Privacy Policy

The full privacy policy should be hosted at a public URL. Below is the recommended content:

---

### Privacy Policy (Summary)

**Last updated:** July 21, 2026

Fixgo ("we," "our," or "us") is committed to protecting your privacy. This policy explains how we collect, use, and share your personal information when you use our mobile application.

**1. Information We Collect**

We collect information you provide directly, including your name, phone number, email address, delivery address, and payment details. We also collect usage data such as app interactions, service requests, and device information.

**2. How We Use Your Information**

Your data is used to provide services, match you with verified professionals, process payments, communicate service updates, and improve our platform.

**3. Information Sharing**

We share necessary information (name, address, service details) with matched professionals to facilitate service delivery. We do not sell your personal data to third parties.

**4. Data Security**

We implement industry-standard security measures including encryption, secure storage, and access controls to protect your data.

**5. Data Retention**

We retain your data only as long as necessary to provide services and comply with legal obligations.

**6. Your Rights**

You may request access to, correction of, or deletion of your personal data at any time by contacting us.

**7. Children's Privacy**

Fixgo is not intended for children under 16. We do not knowingly collect data from minors.

**8. Contact**

For privacy concerns, contact: privacy@fixgo.uz

---

## App Icon Specifications

| Requirement | Specification |
|---|---|
| **File format** | PNG |
| **Size** | 512 x 512 pixels |
| **Color depth** | 32-bit (RGBA) |
| **Max file size** | 1024 KB |
| **Shape** | Google Play will apply adaptive icon masking (circular/squircle) |

The generated app icon (`playstore-icon.png`) meets all specifications.

## Feature Graphic Specifications

| Requirement | Specification |
|---|---|
| **File format** | PNG |
| **Size** | 1024 x 500 pixels |
| **Max file size** | 1024 KB |
| **Aspect ratio** | 2:1 (width:height) |

The generated feature graphic (`playstore-feature-graphic.png`) meets all specifications.

## Phone Screenshot Specifications

| Requirement | Specification |
|---|---|
| **File format** | PNG or JPEG |
| **Minimum size** | 320 x 480 pixels |
| **Maximum size** | 3840 x 2160 pixels |
| **Max per listing** | 8 screenshots |
| **Required** | Minimum 2 screenshots |

The generated screenshots meet all specifications. A tablet screenshot is also included.

---

## Google Play Console Checklist

| Item | Status | Details |
|---|---|---|
| App Title | Ready | "Fixgo — Home Services" |
| Short Description | Ready | UZ/RU/EN versions prepared |
| Long Description | Ready | Full descriptions in 3 languages |
| App Icon (512x512) | Ready | `playstore-icon.png` |
| Feature Graphic (1024x500) | Ready | `playstore-feature-graphic.png` |
| Phone Screenshots | Ready | 5 phone screenshots (320x568 min) |
| Tablet Screenshots | Ready | 1 tablet screenshot (768x1024 min) |
| Content Rating | Ready | Everyone (PEGI 3) |
| Category | Ready | Business / Productivity |
| Privacy Policy URL | Required | Must host at public URL (see below) |
| Contact Email | Required | developer@fixgo.uz |
| Contact Website | Required | https://fixgo-home-hjlhwkjq.manus.space |
| Signed AAB | Required | See Phase 5 instructions |

---

## Next Steps for Publishing

1. **Host the privacy policy** — deploy a dedicated `/privacy` page on the Fixgo website.
2. **Set up Google Play Console account** — create developer account at pay.google.com (one-time $25 fee).
3. **Generate signed release build** — build the PWA, wrap in Trusted Web Activity (TWA) using Bubblewrap CLI.
4. **Upload AAB** — upload the signed Android App Bundle to Google Play Console.
5. **Submit for review** — fill in store listing, set pricing (Free), and submit for Google review.
