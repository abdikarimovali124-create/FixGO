# Fixgo — Design Brainstorm

## Three Approaches

### 1. "Warm Craft" — Artisanal Trust
Very brief intro: Earthy, hand-crafted warmth with cream/olive palette, soft organic shapes, and generous whitespace that evokes "someone trustworthy is coming to your home." Inspired by Scandinavian-adjacent artisanal branding.
Probability: 0.82

### 2. "Urban Pulse" — City Energy
Very brief intro: Bold geometric cuts, high-contrast typography, and kinetic motion that evokes the speed and reliability of urban on-demand services. Think dark mode with neon olive accents.
Probability: 0.11

### 3. "Soft Minimal" — Quiet Confidence
Very brief intro: Near-monochromatic cream with ultra-refined micro-typography, generous negative space, and whisper-quiet animations that communicate "we handle everything so you don't have to worry."
Probability: 0.07

---

## Chosen Approach: "Warm Craft"

### Design Movement
Warm Artisanal Realism — inspired by Scandinavian interior design meets Uzbek cultural warmth. The aesthetic draws from natural materials, earth tones, and the feeling of a well-crafted home where every detail has been considered.

### Core Principles
1. **Trust Through Warmth** — Every visual decision reinforces the feeling that a real person (not a robot) is coming to help. Soft edges, warm tones, organic shapes.
2. **Clarity Over Clutter** — Information hierarchy is paramount. Users always know what they can do next. No visual noise.
3. **Motion as Communication** — Animations aren't decoration; they guide the eye, confirm actions, and create a sense of responsiveness and care.
4. **Cultural Grounding** — Uzbek language first, culturally resonant imagery, warm hospitality feel.

### Color Philosophy
- **Primary Background (#FFFFFF)**: Pure white = cleanliness, professionalism, the freshness of a well-maintained home.
- **Secondary/Section (#F3EFE6)**: Milky cream = warmth, comfort, the feeling of being at home. Creates natural section transitions.
- **Accent (#8A8A63)**: Warm olive/khaki = reliability, nature, grounded trustworthiness. Not aggressive like red, not cold like blue.
- **Text Primary (#1F1E1B)**: Charcoal, never pure black = soft authority, approachable expertise.
- **Text Muted (rgba(31,30,27,0.6))**: Reduced weight without disappearing.

### Layout Paradigm
Asymmetric flow with intentional off-center elements. The page breathes — sections don't all center-align. The hero uses a left-aligned heading with right-aligned visual. The isometric section breaks the grid entirely. Services use a numbered vertical flow. This creates visual interest and prevents the "wall of content" feeling.

### Signature Elements
1. **Magnetic Cursor Interactions** — The hero image subtly follows the cursor, creating a sense of responsiveness and life.
2. **Isometric 3D Card Gallery** — The signature section uses tilted, perspective-driven cards that create depth and premium feel.
3. **Olive-gradient CTAs** — Buttons with a warm gradient (charcoal → olive → cream) that feel like natural materials transitioning.

### Interaction Philosophy
Interactions feel like a conversation, not a command. Hover states reveal options gently. Click states confirm with scale and shadow. Scroll animations guide without overwhelming. The mobile sticky CTA bar ensures users always have a path forward.

### Animation Guidelines
- Hero text: SplitText character-by-character reveal (40ms stagger, ease power3.out)
- Section entrances: FadeIn from below (y: 30, duration 0.7s, ease cubic-bezier(0.25,0.1,0.25,1))
- Marquee: Continuous scroll-driven translateX with will-change: transform
- Isometric cards: GSAP ScrollTrigger scrub: 1 for smooth diagonal glide
- Character reveal: scroll-driven opacity 0.2→1 with offset-based timing
- Reduced motion: All GSAP/Framer animations gated behind prefers-reduced-motion: no-preference

### Typography System
- **Font**: "Manrope" (Google Fonts, weights 300–900), sans-serif, fallback system-ui
- **Hero headings**: clamp(3rem, 10vw, 12rem), font-black, uppercase, tracking-tight
- **Section headings**: clamp(2rem, 8vw, 10rem), font-bold
- **Body**: 16–18px, font-light to font-regular
- **Numbers (services list)**: clamp(3rem, 10vw, 140px), charcoal, oversized
- **Nav links**: text-sm md:text-lg, uppercase, tracking-wide

### Brand Essence
Fixgo is a premium home services platform for Uzbek homeowners who value verified professionals, transparent pricing, and the convenience of on-demand help. It feels like a trusted friend who happens to run a network of skilled tradespeople.

**Personality**: Warm, reliable, unhurried.

### Brand Voice
Headlines are direct and benefit-driven. CTAs are action-oriented in Uzbek. Microcopy is reassuring.

**Example headline**: "Uyingiz uchun barcha xizmatlar — bir bosishda"
**Example CTA**: "Xizmat buyurtma qilish"

### Wordmark & Logo
A bold geometric wrench/house hybrid icon in warm olive (#8A8A63) on transparent background. The mark combines a house silhouette with a subtle wrench curve — immediately communicating "home services" without text. Used in the header at a clearly visible size and as the favicon.

### Signature Brand Color
**Warm Olive (#8A8A63)** — This is unmistakably Fixgo's color. It appears in CTAs, icon backgrounds, card shadows, the isometric section accents, and the footer. It's the thread that ties the entire experience together.
## Style Decisions
- Hero must open with a large left-aligned Uzbek benefit headline, a visible primary CTA, and an off-center human/home-service visual
- No internal keys, generic labels, or placeholder phrasing may appear in UI; all visible text must sound like reassuring Uzbek customer-facing service language
- Service proof imagery should look like real local home work with clear human/tool/context cues and meaningful before/after contrast
- Carry artisanal/asymmetric rhythm: off-center composition, oversized numerals, olive badges, warm material blocks
- Olive should be a recurring brand thread, not just a button color
